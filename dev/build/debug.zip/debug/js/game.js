(function (console) { "use strict";
var $estr = function() { return js_Boot.__string_rec(this,''); };
function $extend(from, fields) {
	function Inherit() {} Inherit.prototype = from; var proto = new Inherit();
	for (var name in fields) proto[name] = fields[name];
	if( fields.toString !== Object.prototype.toString ) proto.toString = fields.toString;
	return proto;
}
var HxOverrides = function() { };
HxOverrides.__name__ = true;
HxOverrides.indexOf = function(a,obj,i) {
	var len = a.length;
	if(i < 0) {
		i += len;
		if(i < 0) i = 0;
	}
	while(i < len) {
		if(a[i] === obj) return i;
		i++;
	}
	return -1;
};
HxOverrides.remove = function(a,obj) {
	var i = HxOverrides.indexOf(a,obj,0);
	if(i == -1) return false;
	a.splice(i,1);
	return true;
};
HxOverrides.iter = function(a) {
	return { cur : 0, arr : a, hasNext : function() {
		return this.cur < this.arr.length;
	}, next : function() {
		return this.arr[this.cur++];
	}};
};
var List = function() {
	this.length = 0;
};
List.__name__ = true;
List.prototype = {
	push: function(item) {
		var x = [item,this.h];
		this.h = x;
		if(this.q == null) this.q = x;
		this.length++;
	}
	,__class__: List
};
var Main = function() {
	this.dt = 0.0;
	this.lastAnimationTime = 0.0;
	this.xKeyDown = false;
	this.screens = new List();
	this.playerReturningToStart = false;
	this.lastPlayerPosition = new THREE.Vector3();
	this.subtitleText = new ludum_CinematicText();
	this.titleText = new ludum_CinematicText();
	this.signal_playerClicked = new msignal_Signal2();
	this.raycastingEnabled = true;
	this.raycaster = new THREE.Raycaster();
	this.interactables = [];
	this.hoveredObjectClickCount = 0;
	this.hoveredObject = null;
	this.signal_hoveredObjectChanged = new msignal_Signal1();
	this.gameTextFractionShown = 0.0;
	this.gameText = null;
	this.skyEffectController = new shaders_SkyEffectController();
	this.uiScene = new THREE.Scene();
	this.signal_screenChangeTrigger = new msignal_Signal2();
	this.worldCameraFollowPoint = new THREE.Vector3();
	this.worldScene = new THREE.Scene();
	this.backdropScene = new THREE.Scene();
	this.mouse = new THREE.Vector2(0.0,0.0);
	this.stats = new Stats();
	this.shaderGUI = new dat.GUI({ autoPlace : true});
	this.particleGUI = new dat.GUI({ autoPlace : true});
	this.sceneGUI = new dat.GUI({ autoPlace : true});
	this.guiItemCount = 0;
	window.onload = $bind(this,this.onWindowLoaded);
};
Main.__name__ = true;
Main.main = function() {
	var main = new Main();
};
Main.getDistanceForObjectHeight = function(fov,height) {
	return height / Math.tan(fov * 0.5 * 0.01745329) * 0.5;
};
Main.getWorldHeightForDistanceAndScreenHeight = function(fov,distance,pixelHeight) {
	return pixelHeight / 500 * (distance / (2 * Math.tan(fov / 2 * 0.01745329)));
};
Main.getFrustumSizeAtDistance = function(fov,aspectRatio,distance) {
	var height = 2.0 * distance * Math.tan(fov * 0.5 * 0.01745329);
	var width = height * aspectRatio;
	return new THREE.Vector2(width,height);
};
Main.prototype = {
	onWindowLoaded: function() {
		var _g = this;
		this.gameAttachPoint = window.document.getElementById("game");
		var gameDiv = window.document.createElement("attach");
		this.gameAttachPoint.appendChild(gameDiv);
		var glSupported = WebGLDetector.detect();
		if(glSupported != 0) {
			var unsupportedInfo = window.document.createElement("div");
			unsupportedInfo.style.position = "absolute";
			unsupportedInfo.style.top = "10px";
			unsupportedInfo.style.width = "100%";
			unsupportedInfo.style.textAlign = "center";
			unsupportedInfo.style.color = "#ffffff";
			switch(glSupported) {
			case 2:
				unsupportedInfo.innerHTML = "Your browser does not support WebGL. Click <a href=\"" + "https://github.com/Tw1ddle/Ludum-Dare-33" + "\" target=\"_blank\">here for screenshots</a> instead.";
				break;
			case 1:
				unsupportedInfo.innerHTML = "Your browser supports WebGL, but the feature appears to be disabled. Click <a href=\"" + "https://github.com/Tw1ddle/Ludum-Dare-33" + "\" target=\"_blank\">here for screenshots</a> instead.";
				break;
			default:
				unsupportedInfo.innerHTML = "Could not detect WebGL support. Click <a href=\"" + "https://github.com/Tw1ddle/Ludum-Dare-33" + "\" target=\"_blank\">here for screenshots</a> instead.";
			}
			gameDiv.appendChild(unsupportedInfo);
			return;
		}
		this.gameText = window.document.createElement("div");
		this.gameText.style.position = "absolute";
		this.gameText.style.bottom = "-30px";
		this.gameText.style.width = "100%";
		this.gameText.style.textAlign = "center";
		this.gameText.style.color = "#444444";
		this.gameText.style.fontSize = "20px";
		this.gameText.innerHTML = "";
		gameDiv.appendChild(this.gameText);
		var credits = window.document.createElement("div");
		credits.style.position = "absolute";
		credits.style.bottom = "-70px";
		credits.style.width = "100%";
		credits.style.textAlign = "center";
		credits.style.color = "#333333";
		credits.innerHTML = "Created by <a href=" + "https://twitter.com/Sam_Twidale" + " target=\"_blank\">Sam Twidale</a> for <a href=" + "http://ludumdare.com/" + " target=\"_blank\">Ludum Dare 33</a>. Get the code <a href=" + "https://github.com/Tw1ddle/Ludum-Dare-33" + " target=\"_blank\">here</a>.";
		gameDiv.appendChild(credits);
		this.renderer = new THREE.WebGLRenderer({ antialias : false});
		this.renderer.sortObjects = false;
		this.renderer.autoClear = false;
		this.renderer.setSize(800,500);
		this.renderer.setClearColor(new THREE.Color(2236962));
		this.worldCamera = new THREE.PerspectiveCamera(20,1.6,0.5,2000000);
		this.worldCameraFollowPoint.set(this.worldCamera.position.x,this.worldCamera.position.y,this.worldCamera.position.z);
		this.uiCamera = new THREE.OrthographicCamera(0,800,0,500,-1,1);
		this.uiCamera.position.set(0,0,0);
		this.backdropCamera = new THREE.OrthographicCamera(0,800,0,500,-1,1);
		this.backdropCamera.position.set(0,0,0);
		this.player = new ludum_Player(this.worldScene,0,-130.,10,30);
		var skyMat = new THREE.ShaderMaterial({ fragmentShader : shaders_SkyShader.fragmentShader, vertexShader : shaders_SkyShader.vertexShader, uniforms : shaders_SkyShader.uniforms, side : THREE.BackSide});
		var skyMesh = new THREE.Mesh(new THREE.SphereGeometry(450000,32,15),skyMat);
		skyMesh.name = "Sky Mesh";
		this.worldScene.add(skyMesh);
		this.starGroup = new SPE.Group({ texture : THREE.ImageUtils.loadTexture("assets/images/icefly.png"), maxAge : 3});
		this.starEmitter = new SPE.Emitter({ type : "cube", position : new THREE.Vector3(0,0,-14170), positionSpread : new THREE.Vector3(9600.,5000.,0), acceleration : new THREE.Vector3(0,0,0), accelerationSpread : new THREE.Vector3(0,0,0), velocity : new THREE.Vector3(0,0,0), velocitySpread : new THREE.Vector3(0,0,0), particleCount : 2000, opacityStart : 0.0, opacityMiddle : 0.6, opacityMiddleSpread : 0.4, opacityEnd : 0.0, sizeStart : 220});
		this.starGroup.mesh.name = "Star Particle Group";
		this.starGroup.addEmitter(this.starEmitter);
		this.starGroup.mesh.frustumCulled = false;
		this.worldScene.add(this.starGroup.mesh);
		this.windGroup = new SPE.Group({ texture : THREE.ImageUtils.loadTexture("assets/images/firefly.png"), maxAge : 5});
		this.windEmitter = new SPE.Emitter({ type : "cube", position : new THREE.Vector3(800,0,-1417), positionSpread : new THREE.Vector3(100,500,0), acceleration : new THREE.Vector3(1,0,0), accelerationSpread : new THREE.Vector3(17,47,-127), velocity : new THREE.Vector3(-576,0,0), velocitySpread : new THREE.Vector3(0,0,0), sizeStart : 10, sizeEnd : 10, opacityStart : 0, opacityMiddle : 1, opacityEnd : 0, particleCount : 5000, alive : 0});
		this.windGroup.mesh.name = "Wind Particle Group";
		this.windGroup.addEmitter(this.windEmitter);
		this.windGroup.mesh.frustumCulled = false;
		this.worldScene.add(this.windGroup.mesh);
		this.screenZero = new ludum_screens_ScreenZero(this,new THREE.Vector2(0,0));
		this.screenOne = new ludum_screens_ScreenOne(this,new THREE.Vector2(1,0));
		this.screenTwo = new ludum_screens_ScreenTwo(this,new THREE.Vector2(2,0));
		this.screens.push(this.screenZero);
		this.screens.push(this.screenOne);
		this.screens.push(this.screenTwo);
		var narrative = ["For the tombs of my priests to be haunted by such spirits...","Could it be that my disciples have abandoned me...?","Or that the faithful multitudes have forgotten me...?","That would be......","...UNFORGIVEABLE!","...The impudence! How dare they dishonour me so!","I shall scour this land and hunt for the unfaithful ones...","I shall hasten through long nights...","Where the stars wheel overhead...","Traveling onwards, even if the wind bears against me...","And even if I come unto the sea of Otherworldly Stars...","...","......",".........","And far beyond...into the void...","...This can mean but one thing...","My wretched followers dared to flee unto the ends of the Earth...!","I shall slay them all...!","...THEY SHALL WITHER BEFORE THE LORD OF FIRE"];
		var _g1 = 0;
		var _g2 = narrative.length;
		while(_g1 < _g2) {
			var i = _g1++;
			this.screens.push(new ludum_screens_RandomScreen(this,new THREE.Vector2(2 + i,0),narrative[i]));
		}
		this.screenThree = new ludum_screens_ScreenThree(this,new THREE.Vector2(narrative.length - 1 + 3,0));
		this.screenFour = new ludum_screens_ScreenFour(this,new THREE.Vector2(narrative.length - 1 + 4,0));
		this.screens.push(this.screenThree);
		this.screens.push(this.screenFour);
		this.titleText.init("Otherworldly Stars");
		this.subtitleText.init("You Are The Monster");
		this.worldScene.add(this.titleText);
		this.worldScene.add(this.subtitleText);
		this.interactables.push(this.player);
		this.player.signal_PositionChanged.add($bind(this,this.onPlayerMoved));
		this.player.signal_Died.add($bind(this,this.onPlayerDied));
		this.signal_screenChangeTrigger.add($bind(this,this.onScreenChange));
		this.signal_hoveredObjectChanged.add($bind(this,this.onHoveredObjectChanged));
		this.signal_playerClicked.add($bind(this,this.onObjectClicked));
		window.document.addEventListener("resize",function(event) {
		},false);
		this.player.setupInputEvents();
		window.document.addEventListener("mousedown",function(event1) {
			event1.preventDefault();
			_g.mouse.x = MathUtils.clamp((event1.clientX - _g.gameAttachPoint.offsetLeft) / _g.gameAttachPoint.clientWidth * 2 - 1,-1,1);
			_g.mouse.y = MathUtils.clamp(-((event1.clientY - _g.gameAttachPoint.offsetTop) / _g.gameAttachPoint.clientHeight) * 2 + 1,-1,1);
			_g.signal_playerClicked.dispatch(_g.mouse.x,_g.mouse.y);
		},false);
		window.document.addEventListener("mouseup",function(event2) {
			event2.preventDefault();
			_g.mouse.x = MathUtils.clamp((event2.clientX - _g.gameAttachPoint.offsetLeft) / _g.gameAttachPoint.clientWidth * 2 - 1,-1,1);
			_g.mouse.y = MathUtils.clamp(-((event2.clientY - _g.gameAttachPoint.offsetTop) / _g.gameAttachPoint.clientHeight) * 2 + 1,-1,1);
		},false);
		window.document.addEventListener("mousemove",function(event3) {
			event3.preventDefault();
			_g.mouse.x = MathUtils.clamp((event3.clientX - _g.gameAttachPoint.offsetLeft) / _g.gameAttachPoint.clientWidth * 2 - 1,-1,1);
			_g.mouse.y = MathUtils.clamp(-((event3.clientY - _g.gameAttachPoint.offsetTop) / _g.gameAttachPoint.clientHeight) * 2 + 1,-1,1);
		},false);
		window.document.addEventListener("keydown",function(event4) {
			var charCode = event4.keyCode;
			if(charCode == 88) {
				_g.xKeyDown = true;
				_g.player.signal_Died.dispatch();
			}
		},false);
		window.document.addEventListener("keyup",function(event5) {
			var charCode1 = event5.keyCode;
			if(charCode1 == 88) _g.xKeyDown = false;
		},false);
		window.document.addEventListener("contextmenu",function(event6) {
			event6.preventDefault();
		},false);
		window.document.addEventListener("DOMMouseScroll",function(event7) {
			event7.preventDefault();
		},false);
		this.stats.domElement.style.position = "absolute";
		this.stats.domElement.style.top = "0px";
		window.document.body.appendChild(this.stats.domElement);
		this.setupGUI();
		this.runGameIntro();
		gameDiv.appendChild(this.renderer.domElement);
		window.requestAnimationFrame($bind(this,this.animate));
	}
	,runGameIntro: function() {
		var _g = this;
		this.player.set_inputEnabled(false);
		this.worldCamera.position.set(-1200,0,0);
		this.skyEffectController.inclination = 0.5160;
		this.skyEffectController.azimuth = 0.1700;
		this.skyEffectController.cameraPos.set(-163500,-100000,-415000);
		this.skyEffectController.primaries.set(5.7e-7,5.8e-7,6.0e-7);
		this.skyEffectController.updateUniforms();
		this.starEmitter.acceleration.set(0,0,230);
		this.starEmitter.accelerationSpread.set(59,57,516);
		this.titleText.position.set(-1000,50,-1400);
		this.titleText.tween(function() {
			_g.player.set_inputEnabled(true);
		});
		this.subtitleText.position.set(-1000,-50,-1400);
		this.subtitleText.tween();
		this.screenZero.starEmitter.alive = 1.0;
		motion_Actuate.tween(this.screenZero.starEmitter,5,{ alive : 0.03}).delay(4);
		motion_Actuate.tween(this.worldCamera.position,6,{ x : Math.round(this.player.position.x / 800) * 800}).delay(3).ease(motion_easing_Sine.get_easeInOut()).onComplete(function() {
			_g.setGameText("Arrow keys to move, click and hover to interact.","#AAAAAA",null,null,null);
		});
		motion_Actuate.tween(this.skyEffectController,9,{ inclination : 0.4983, azimuth : 0.1979, turbidity : 4.7, rayleigh : 2.28, mieDirectionalG : 0.820, refractiveIndex : 1.00029, mieV : 3.936, mieZenithLength : 34000, sunAngularDiameter : 0.00830, depolarizationFactor : 0.020}).onUpdate(function() {
			_g.skyEffectController.updateUniforms();
		}).onComplete(function() {
			motion_Actuate.tween(_g.starEmitter,3,{ alive : 0.5, opacityMiddle : 0.3}).delay(5);
			_g.starEmitter.acceleration.set(0,0,0);
			_g.starEmitter.accelerationSpread.set(0,0,0);
		}).ease(motion_easing_Sine.get_easeInOut());
		motion_Actuate.tween(this.skyEffectController.cameraPos,5,{ x : 100000, y : -40000, z : 0}).delay(3).onUpdate(function() {
			_g.skyEffectController.updateUniforms();
		}).ease(motion_easing_Sine.get_easeInOut());
		motion_Actuate.tween(this.skyEffectController.primaries,5,{ x : 6.8e-7, y : 5.5e-7, z : 4.5e-7}).delay(5).onUpdate(function() {
			_g.skyEffectController.updateUniforms();
		}).ease(motion_easing_Sine.get_easeInOut());
	}
	,showText: function(message,onShowComplete,onHideComplete) {
		this.titleText.init(message);
		this.titleText.tween(onShowComplete,onHideComplete);
	}
	,updateMousePosition: function(x,y) {
		this.mouse.x = MathUtils.clamp((x - this.gameAttachPoint.offsetLeft) / this.gameAttachPoint.clientWidth * 2 - 1,-1,1);
		this.mouse.y = MathUtils.clamp(-((y - this.gameAttachPoint.offsetTop) / this.gameAttachPoint.clientHeight) * 2 + 1,-1,1);
	}
	,onHoveredObjectChanged: function(o) {
		this.hoveredObjectClickCount = 0;
		if(o != null) {
			if(js_Boot.__instanceof(o,ludum_Describable)) {
				var describable = o;
				this.setGameText(describable.hoverText,null,null,null,null);
			} else if(js_Boot.__instanceof(o,ludum_Player)) {
				var player = o;
				this.setGameText(ludum_Player.randomMessage(Std["int"](Math.random() * 3)),null,null,null,null);
			}
		} else this.setGameText("",null,null,null,null);
	}
	,setGameText: function(text,color,showDuration,ease,onComplete) {
		if(color == null) color = "#990000";
		var _g = this;
		if(showDuration == null) showDuration = text.length * 0.04;
		if(ease == null) ease = motion_easing_Linear.get_easeNone();
		if(onComplete == null) onComplete = function() {
		};
		this.gameTextFractionShown = 0.0;
		motion_Actuate.tween(this,showDuration,{ gameTextFractionShown : 1.0}).onUpdate(function() {
			_g.gameText.innerHTML = text.substring(0,text.length * _g.gameTextFractionShown | 0);
			_g.gameText.style.color = color;
		}).ease(ease).onComplete(onComplete);
	}
	,onObjectClicked: function(x,y) {
		if(this.hoveredObject != null) {
			if(js_Boot.__instanceof(this.hoveredObject,ludum_Describable)) {
				var describable = this.hoveredObject;
				this.setGameText(describable.clickText(this.hoveredObjectClickCount),null,null,null,null);
				this.hoveredObjectClickCount++;
			}
		}
	}
	,onPlayerDied: function() {
		var _g = this;
		this.playerReturningToStart = true;
		this.player.set_inputEnabled(false);
		this.raycastingEnabled = false;
		var duration = ludum_ScreenSwitcher.getScreenIndices(this.lastPlayerPosition).x * 0.4;
		this.setGameText(this.makeDeathMessage(),null,duration,motion_easing_Quad.get_easeInOut(),null);
		motion_Actuate.tween(this.player.position,duration,{ x : 0}).onUpdate(function() {
			_g.player.signal_PositionChanged.dispatch(_g.player.position);
			if(_g.player.position.x < 1000) _g.screenZero.starEmitter.alive = 1.0;
		}).onComplete(function() {
			_g.setGameText(".........",null,3,null,null);
			motion_Actuate.tween(_g.screenZero.starEmitter,2,{ alive : 0.1}).onComplete(function() {
				_g.restoreSkyToDefaults(3);
				_g.restoreStarsToDefaults();
				_g.playerReturningToStart = false;
				var _g1_head = _g.screens.h;
				var _g1_val = null;
				while(_g1_head != null) {
					var screen;
					screen = (function($this) {
						var $r;
						_g1_val = _g1_head[0];
						_g1_head = _g1_head[1];
						$r = _g1_val;
						return $r;
					}(this));
					screen.reset();
				}
				_g.player.set_inputEnabled(true);
				_g.player.reset();
				_g.raycastingEnabled = true;
			});
		}).ease(motion_easing_Quad.get_easeInOut());
		motion_Actuate.tween(this.worldCameraFollowPoint,duration,{ x : 0}).onUpdate(function() {
			_g.worldCamera.position.x = _g.worldCameraFollowPoint.x;
		}).ease(motion_easing_Quad.get_easeInOut());
	}
	,makeDeathMessage: function() {
		var msg = "";
		var _g = 0;
		while(_g < 5) {
			var i = _g++;
			var rand = Math.random();
			if(rand < 0.1) msg += "Noooooooooo..."; else if(rand > 0.1 && rand < 0.3) msg += "Aaaaarrrrrgh..."; else if(rand > 0.3 && rand < 0.5) msg += "Urrrrrarrrrr!!!..."; else if(rand < 0.7) msg += "It can't end this way!..."; else if(rand < 0.9) msg += "Gaaaahhhh..."; else msg += "Urrrrrrrgh...";
		}
		return msg;
	}
	,onPlayerMoved: function(position) {
		if(ludum_ScreenSwitcher.checkForBoundaryCrossing(this.lastPlayerPosition,position)) {
			var currentIndex = ludum_ScreenSwitcher.getScreenIndices(this.lastPlayerPosition);
			var nextIndex = new THREE.Vector2(Math.round(position.x / 800),position.y / 500 | 0);
			if(nextIndex.x == -1) {
				console.log("Rejecting screen change to negative screen index");
				this.player.position.set(this.lastPlayerPosition.x,this.lastPlayerPosition.y,this.lastPlayerPosition.z);
			} else if(this.player.position.x < 0) {
				console.log("Rejecting player movement because it would go into negative x");
				this.player.position.set(0,0,this.lastPlayerPosition.z);
			} else {
				var current = ludum_screens_Screen.findScreen(currentIndex,this.screens);
				var next = ludum_screens_Screen.findScreen(nextIndex,this.screens);
				if(current == null || current.permitsTransition(next)) this.signal_screenChangeTrigger.dispatch(current,next);
			}
		}
		this.lastPlayerPosition.set(position.x,position.y,position.z);
	}
	,onScreenChange: function(current,next) {
		if(current != null) {
			current.onExit();
			current.set_active(false);
		}
		if(next != null) {
			next.set_active(true);
			next.onEnter();
		}
		if(!this.playerReturningToStart) {
			this.worldCameraFollowPoint.x = Math.round(this.player.position.x / 800) * 800;
			motion_Actuate.tween(this.worldCamera.position,1,{ x : this.worldCameraFollowPoint.x}).ease(motion_easing_Sine.get_easeOut());
		}
	}
	,restoreSkyToDefaults: function(duration,inclination,azimuth) {
		if(azimuth == null) azimuth = 0.1979;
		if(inclination == null) inclination = 0.4983;
		if(duration == null) duration = 3;
		var _g = this;
		motion_Actuate.tween(this.skyEffectController,duration,{ turbidity : 4.7, rayleigh : 2.28, mieCoefficient : 0.005, mieDirectionalG : 0.82, luminance : 1.00, inclination : inclination, azimuth : azimuth, refractiveIndex : 1.00029, numMolecules : 2.542e25, depolarizationFactor : 0.02, rayleighZenithLength : 8400, mieV : 3.936, mieZenithLength : 34000, sunIntensityFactor : 1000, sunIntensityFalloffSteepness : 1.5, sunAngularDiameterDegrees : 0.00933}).onUpdate(function() {
			_g.skyEffectController.updateUniforms();
		});
		motion_Actuate.tween(this.skyEffectController.primaries,duration,{ x : 6.8e-7, y : 5.5e-7, z : 4.5e-7}).onUpdate(function() {
			_g.skyEffectController.updateUniforms();
		});
		motion_Actuate.tween(this.skyEffectController.cameraPos,duration,{ x : 100000, y : -40000, z : 0}).onUpdate(function() {
			_g.skyEffectController.updateUniforms();
		});
		motion_Actuate.tween(this.skyEffectController.mieKCoefficient,duration,{ x : 0.686, y : 0.678, z : 0.666}).onUpdate(function() {
			_g.skyEffectController.updateUniforms();
		});
	}
	,restoreStarsToDefaults: function() {
		this.starEmitter.position.set(0,0,-14170);
		this.starEmitter.positionSpread.set(9600.,5000.,0);
		this.starEmitter.acceleration.set(0,0,0);
		this.starEmitter.accelerationSpread.set(0,0,0);
		this.starEmitter.velocity.set(0,0,0);
		this.starEmitter.velocitySpread.set(0,0,0);
		this.starEmitter.particleCount = 2000;
		this.starEmitter.opacityStart = 0.0;
		this.starEmitter.opacityMiddle = 0.3;
		this.starEmitter.opacityEnd = 0.0;
		this.starEmitter.sizeStart = 220;
		this.starEmitter.sizeMiddle = 220;
		this.starEmitter.sizeEnd = 220;
		this.starEmitter.alive = 0.5;
	}
	,animate: function(time) {
		this.dt = (time - this.lastAnimationTime) * 0.001;
		this.lastAnimationTime = time;
		if(this.raycastingEnabled) {
			this.raycaster.setFromCamera(this.mouse,this.worldCamera);
			var hovereds = this.raycaster.intersectObjects(this.interactables);
			if(hovereds.length > 0) {
				if(this.hoveredObject != hovereds[0].object) {
					this.hoveredObject = hovereds[0].object;
					this.signal_hoveredObjectChanged.dispatch(this.hoveredObject);
				}
			} else {
				if(this.hoveredObject != null) this.signal_hoveredObjectChanged.dispatch(null);
				this.hoveredObject = null;
			}
		}
		this.starEmitter.position.set(this.worldCamera.position.x,this.worldCamera.position.y,-14170);
		this.windEmitter.position.set(this.worldCamera.position.x + 1600.,this.worldCamera.position.y,-1417);
		this.starGroup.tick(this.dt);
		this.windGroup.tick(this.dt);
		this.titleText.update(this.dt);
		this.player.update(this.dt);
		var _g_head = this.screens.h;
		var _g_val = null;
		while(_g_head != null) {
			var screen;
			screen = (function($this) {
				var $r;
				_g_val = _g_head[0];
				_g_head = _g_head[1];
				$r = _g_val;
				return $r;
			}(this));
			screen.update(this.dt);
		}
		this.renderer.clear();
		this.renderer.render(this.backdropScene,this.backdropCamera);
		this.renderer.clearDepth();
		this.renderer.render(this.worldScene,this.worldCamera);
		this.renderer.clearDepth();
		this.renderer.render(this.uiScene,this.uiCamera);
		this.stats.update();
		window.requestAnimationFrame($bind(this,this.animate));
	}
	,setupStats: function() {
		this.stats.domElement.style.position = "absolute";
		this.stats.domElement.style.top = "0px";
		window.document.body.appendChild(this.stats.domElement);
	}
	,setupGUI: function() {
		this.addGUIItem(this.sceneGUI,this.worldCamera,"World Camera");
		this.addGUIItem(this.sceneGUI,this.uiCamera,"UI Camera");
		var _g = 0;
		var _g1 = this.worldScene.children;
		while(_g < _g1.length) {
			var item = _g1[_g];
			++_g;
			this.addGUIItem(this.sceneGUI,item);
		}
		this.addGUIItem(this.particleGUI.addFolder("Player Emitter"),this.player.particleEmitter,"Player Emitter");
		this.addGUIItem(this.particleGUI.addFolder("Player Blast Emitter"),this.player.blastParticleEmitter,"Player Blast Emitter");
		this.addGUIItem(this.particleGUI.addFolder("Star Emitter"),this.starEmitter,"Star Emitter");
		this.addGUIItem(this.particleGUI.addFolder("Wind Emitter"),this.windEmitter,"Wind Emitter");
		var screenCount = 0;
		var _g_head = this.screens.h;
		var _g_val = null;
		while(_g_head != null) {
			var screen;
			screen = (function($this) {
				var $r;
				_g_val = _g_head[0];
				_g_head = _g_head[1];
				$r = _g_val;
				return $r;
			}(this));
			screen.addGUIItems(this.particleGUI);
			var enemyCount = 0;
			var _g2 = 0;
			var _g11 = screen.enemies;
			while(_g2 < _g11.length) {
				var enemy = _g11[_g2];
				++_g2;
				this.addGUIItem(this.particleGUI.addFolder("Enemy Emitter " + "(screen: " + screenCount + ", enemy: " + enemyCount + ")"),enemy.particleEmitter,"Enemy Emitter");
				enemyCount++;
			}
			screenCount++;
		}
		this.addGUIItem(this.shaderGUI,this.skyEffectController,"Sky Shader");
	}
	,addGUIItem: function(gui,object,tag) {
		if(gui == null || object == null) return null;
		var folder = null;
		if(tag != null) folder = gui.addFolder(tag + " (" + this.guiItemCount++ + ")"); else {
			var name = Std.string(Reflect.field(object,"name"));
			if(name == null || name.length == 0) folder = gui.addFolder("Item (" + this.guiItemCount++ + ")"); else folder = gui.addFolder(Std.string(Reflect.getProperty(object,"name")) + " (" + this.guiItemCount++ + ")");
		}
		if(js_Boot.__instanceof(object,THREE.Object3D)) {
			var object3d = object;
			folder.add(object3d.position,"x",-5000.0,5000.0,2).listen();
			folder.add(object3d.position,"y",-5000.0,5000.0,2).listen();
			folder.add(object3d.position,"z",-20000.0,20000.0,2).listen();
			folder.add(object3d.rotation,"x",0.0,Math.PI * 2,0.1).listen();
			folder.add(object3d.rotation,"y",0.0,Math.PI * 2,0.1).listen();
			folder.add(object3d.rotation,"z",0.0,Math.PI * 2,0.1).listen();
			folder.add(object3d.scale,"x",0.0,10.0,0.1).listen();
			folder.add(object3d.scale,"y",0.0,10.0,0.1).listen();
			folder.add(object3d.scale,"z",0.0,10.0,0.1).listen();
			folder.add(object3d,"visible");
		}
		if(js_Boot.__instanceof(object,THREE.Mesh)) {
			var mesh = object;
			var materialFolder = folder.addFolder("material (" + this.guiItemCount + ")");
			materialFolder.add(mesh.material,"opacity",0,1,0.01).listen();
		}
		if(js_Boot.__instanceof(object,THREE.PerspectiveCamera)) {
			var camera = object;
		}
		if(js_Boot.__instanceof(object,THREE.OrthographicCamera)) {
			var camera1 = object;
		}
		if(js_Boot.__instanceof(object,SPE.Emitter)) {
			var emitter = object;
			gui.add(emitter,"type",["cube","sphere","disk"]);
			var fields = Reflect.fields(emitter);
			var _g = 0;
			while(_g < fields.length) {
				var field = fields[_g];
				++_g;
				var prop = Reflect.getProperty(emitter,field);
				if(js_Boot.__instanceof(prop,THREE.Color)) {
					var folder1 = gui.addFolder(field);
					folder1.add(prop,"r",0,1,0.01).listen();
					folder1.add(prop,"g",0,1,0.01).listen();
					folder1.add(prop,"b",0,1,0.01).listen();
				} else if(js_Boot.__instanceof(prop,THREE.Vector3)) {
					var folder2 = gui.addFolder(field);
					folder2.add(prop,"x",-2000,2000,0.1).listen();
					folder2.add(prop,"y",-2000,2000,0.1).listen();
					folder2.add(prop,"z",-4000,4000,0.1).listen();
				} else if(typeof(prop) == "number") gui.add(emitter,field,0.04).listen();
			}
		}
		if(js_Boot.__instanceof(object,shaders_SkyEffectController)) {
			var controller = object;
			controller.addGUIItem(controller,gui);
		}
		return folder;
	}
	,__class__: Main
};
Math.__name__ = true;
var MathUtils = function() { };
MathUtils.__name__ = true;
MathUtils.clamp = function(value,min,max) {
	if(value < min) return min;
	if(value > max) return max;
	return value;
};
var Reflect = function() { };
Reflect.__name__ = true;
Reflect.field = function(o,field) {
	try {
		return o[field];
	} catch( e ) {
		if (e instanceof js__$Boot_HaxeError) e = e.val;
		return null;
	}
};
Reflect.setField = function(o,field,value) {
	o[field] = value;
};
Reflect.getProperty = function(o,field) {
	var tmp;
	if(o == null) return null; else if(o.__properties__ && (tmp = o.__properties__["get_" + field])) return o[tmp](); else return o[field];
};
Reflect.setProperty = function(o,field,value) {
	var tmp;
	if(o.__properties__ && (tmp = o.__properties__["set_" + field])) o[tmp](value); else o[field] = value;
};
Reflect.callMethod = function(o,func,args) {
	return func.apply(o,args);
};
Reflect.fields = function(o) {
	var a = [];
	if(o != null) {
		var hasOwnProperty = Object.prototype.hasOwnProperty;
		for( var f in o ) {
		if(f != "__id__" && f != "hx__closures__" && hasOwnProperty.call(o,f)) a.push(f);
		}
	}
	return a;
};
Reflect.isFunction = function(f) {
	return typeof(f) == "function" && !(f.__name__ || f.__ename__);
};
Reflect.compareMethods = function(f1,f2) {
	if(f1 == f2) return true;
	if(!Reflect.isFunction(f1) || !Reflect.isFunction(f2)) return false;
	return f1.scope == f2.scope && f1.method == f2.method && f1.method != null;
};
var Std = function() { };
Std.__name__ = true;
Std.string = function(s) {
	return js_Boot.__string_rec(s,"");
};
Std["int"] = function(x) {
	return x | 0;
};
var Type = function() { };
Type.__name__ = true;
Type.createInstance = function(cl,args) {
	var _g = args.length;
	switch(_g) {
	case 0:
		return new cl();
	case 1:
		return new cl(args[0]);
	case 2:
		return new cl(args[0],args[1]);
	case 3:
		return new cl(args[0],args[1],args[2]);
	case 4:
		return new cl(args[0],args[1],args[2],args[3]);
	case 5:
		return new cl(args[0],args[1],args[2],args[3],args[4]);
	case 6:
		return new cl(args[0],args[1],args[2],args[3],args[4],args[5]);
	case 7:
		return new cl(args[0],args[1],args[2],args[3],args[4],args[5],args[6]);
	case 8:
		return new cl(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]);
	default:
		throw new js__$Boot_HaxeError("Too many arguments");
	}
	return null;
};
var haxe_IMap = function() { };
haxe_IMap.__name__ = true;
var haxe_Timer = function(time_ms) {
	var me = this;
	this.id = setInterval(function() {
		me.run();
	},time_ms);
};
haxe_Timer.__name__ = true;
haxe_Timer.stamp = function() {
	return new Date().getTime() / 1000;
};
haxe_Timer.prototype = {
	run: function() {
	}
	,__class__: haxe_Timer
};
var haxe_ds_ObjectMap = function() {
	this.h = { };
	this.h.__keys__ = { };
};
haxe_ds_ObjectMap.__name__ = true;
haxe_ds_ObjectMap.__interfaces__ = [haxe_IMap];
haxe_ds_ObjectMap.prototype = {
	set: function(key,value) {
		var id = key.__id__ || (key.__id__ = ++haxe_ds_ObjectMap.count);
		this.h[id] = value;
		this.h.__keys__[id] = key;
	}
	,remove: function(key) {
		var id = key.__id__;
		if(this.h.__keys__[id] == null) return false;
		delete(this.h[id]);
		delete(this.h.__keys__[id]);
		return true;
	}
	,keys: function() {
		var a = [];
		for( var key in this.h.__keys__ ) {
		if(this.h.hasOwnProperty(key)) a.push(this.h.__keys__[key]);
		}
		return HxOverrides.iter(a);
	}
	,iterator: function() {
		return { ref : this.h, it : this.keys(), hasNext : function() {
			return this.it.hasNext();
		}, next : function() {
			var i = this.it.next();
			return this.ref[i.__id__];
		}};
	}
	,__class__: haxe_ds_ObjectMap
};
var js__$Boot_HaxeError = function(val) {
	Error.call(this);
	this.val = val;
	this.message = String(val);
	if(Error.captureStackTrace) Error.captureStackTrace(this,js__$Boot_HaxeError);
};
js__$Boot_HaxeError.__name__ = true;
js__$Boot_HaxeError.__super__ = Error;
js__$Boot_HaxeError.prototype = $extend(Error.prototype,{
	__class__: js__$Boot_HaxeError
});
var js_Boot = function() { };
js_Boot.__name__ = true;
js_Boot.getClass = function(o) {
	if((o instanceof Array) && o.__enum__ == null) return Array; else {
		var cl = o.__class__;
		if(cl != null) return cl;
		var name = js_Boot.__nativeClassName(o);
		if(name != null) return js_Boot.__resolveNativeClass(name);
		return null;
	}
};
js_Boot.__string_rec = function(o,s) {
	if(o == null) return "null";
	if(s.length >= 5) return "<...>";
	var t = typeof(o);
	if(t == "function" && (o.__name__ || o.__ename__)) t = "object";
	switch(t) {
	case "object":
		if(o instanceof Array) {
			if(o.__enum__) {
				if(o.length == 2) return o[0];
				var str2 = o[0] + "(";
				s += "\t";
				var _g1 = 2;
				var _g = o.length;
				while(_g1 < _g) {
					var i1 = _g1++;
					if(i1 != 2) str2 += "," + js_Boot.__string_rec(o[i1],s); else str2 += js_Boot.__string_rec(o[i1],s);
				}
				return str2 + ")";
			}
			var l = o.length;
			var i;
			var str1 = "[";
			s += "\t";
			var _g2 = 0;
			while(_g2 < l) {
				var i2 = _g2++;
				str1 += (i2 > 0?",":"") + js_Boot.__string_rec(o[i2],s);
			}
			str1 += "]";
			return str1;
		}
		var tostr;
		try {
			tostr = o.toString;
		} catch( e ) {
			if (e instanceof js__$Boot_HaxeError) e = e.val;
			return "???";
		}
		if(tostr != null && tostr != Object.toString && typeof(tostr) == "function") {
			var s2 = o.toString();
			if(s2 != "[object Object]") return s2;
		}
		var k = null;
		var str = "{\n";
		s += "\t";
		var hasp = o.hasOwnProperty != null;
		for( var k in o ) {
		if(hasp && !o.hasOwnProperty(k)) {
			continue;
		}
		if(k == "prototype" || k == "__class__" || k == "__super__" || k == "__interfaces__" || k == "__properties__") {
			continue;
		}
		if(str.length != 2) str += ", \n";
		str += s + k + " : " + js_Boot.__string_rec(o[k],s);
		}
		s = s.substring(1);
		str += "\n" + s + "}";
		return str;
	case "function":
		return "<function>";
	case "string":
		return o;
	default:
		return String(o);
	}
};
js_Boot.__interfLoop = function(cc,cl) {
	if(cc == null) return false;
	if(cc == cl) return true;
	var intf = cc.__interfaces__;
	if(intf != null) {
		var _g1 = 0;
		var _g = intf.length;
		while(_g1 < _g) {
			var i = _g1++;
			var i1 = intf[i];
			if(i1 == cl || js_Boot.__interfLoop(i1,cl)) return true;
		}
	}
	return js_Boot.__interfLoop(cc.__super__,cl);
};
js_Boot.__instanceof = function(o,cl) {
	if(cl == null) return false;
	switch(cl) {
	case Int:
		return (o|0) === o;
	case Float:
		return typeof(o) == "number";
	case Bool:
		return typeof(o) == "boolean";
	case String:
		return typeof(o) == "string";
	case Array:
		return (o instanceof Array) && o.__enum__ == null;
	case Dynamic:
		return true;
	default:
		if(o != null) {
			if(typeof(cl) == "function") {
				if(o instanceof cl) return true;
				if(js_Boot.__interfLoop(js_Boot.getClass(o),cl)) return true;
			} else if(typeof(cl) == "object" && js_Boot.__isNativeObj(cl)) {
				if(o instanceof cl) return true;
			}
		} else return false;
		if(cl == Class && o.__name__ != null) return true;
		if(cl == Enum && o.__ename__ != null) return true;
		return o.__enum__ == cl;
	}
};
js_Boot.__cast = function(o,t) {
	if(js_Boot.__instanceof(o,t)) return o; else throw new js__$Boot_HaxeError("Cannot cast " + Std.string(o) + " to " + Std.string(t));
};
js_Boot.__nativeClassName = function(o) {
	var name = js_Boot.__toStr.call(o).slice(8,-1);
	if(name == "Object" || name == "Function" || name == "Math" || name == "JSON") return null;
	return name;
};
js_Boot.__isNativeObj = function(o) {
	return js_Boot.__nativeClassName(o) != null;
};
js_Boot.__resolveNativeClass = function(name) {
	return (Function("return typeof " + name + " != \"undefined\" ? " + name + " : null"))();
};
var ludum_CinematicText = function() {
	this.signal_Complete = new msignal_Signal0();
	this.letters = [];
	THREE.Object3D.call(this);
	this.name = "Cinematic Text";
};
ludum_CinematicText.__name__ = true;
ludum_CinematicText.__super__ = THREE.Object3D;
ludum_CinematicText.prototype = $extend(THREE.Object3D.prototype,{
	init: function(message) {
		var _g1 = 0;
		var _g = message.length;
		while(_g1 < _g) {
			var i = _g1++;
			var material = new THREE.MeshBasicMaterial({ color : 10027008, overdraw : 0.5, transparent : true, opacity : 1.0});
			var geometry = new THREE.TextGeometry(message.charAt(i),{ size : 24, height : 20, curveSegments : 2, font : "absender"});
			var mesh = new THREE.Mesh(geometry,material);
			this.letters.push(mesh);
			this.add(mesh);
		}
		var x = 0;
		var _g2 = 0;
		var _g11 = this.letters;
		while(_g2 < _g11.length) {
			var letter = _g11[_g2];
			++_g2;
			letter.position.x = x;
			letter.scale.z = 0.0;
			letter.material.opacity = 0.0;
			x += 18;
		}
	}
	,tween: function(onTweenInComplete,onTweenOutComplete) {
		var _g2 = this;
		var tweenDuration = this.letters.length * 0.15;
		var _g1 = 0;
		var _g = this.letters.length;
		while(_g1 < _g) {
			var i = [_g1++];
			motion_Actuate.tween(this.letters[i[0]].position,tweenDuration,{ x : this.letters[i[0]].position.x - 300, y : this.letters[i[0]].position.y + 30}).delay(i[0] * 0.1).ease(motion_easing_Sine.get_easeInOut());
			motion_Actuate.tween(this.letters[i[0]].material,tweenDuration,{ opacity : 1}).onComplete((function(i) {
				return function(v) {
					if(i[0] == _g2.letters.length - 1 && onTweenInComplete != null) onTweenInComplete();
					motion_Actuate.tween(_g2.letters[i[0]].material,tweenDuration,{ opacity : 0});
					motion_Actuate.tween(_g2.letters[i[0]].position,tweenDuration,{ x : _g2.letters[i[0]].position.x - 300, y : _g2.letters[i[0]].position.y + 30}).ease(motion_easing_Sine.get_easeInOut()).onComplete((function(i) {
						return function(v1) {
							if(i[0] == _g2.letters.length - 1 && onTweenOutComplete != null) onTweenOutComplete();
						};
					})(i));
				};
			})(i)).delay(i[0] * 0.1);
		}
	}
	,update: function(dt) {
	}
	,computeBoundingBox: function() {
		return new THREE.Box3().setFromObject(this);
	}
	,__class__: ludum_CinematicText
});
var ludum_Describable = function() { };
ludum_Describable.__name__ = true;
ludum_Describable.prototype = {
	__class__: ludum_Describable
};
var ludum_DescribableMesh = function(geometry,material,hoverText,clickText) {
	THREE.Mesh.call(this,geometry,material);
	this.hoverText = hoverText;
	this.clickMessages = clickText;
};
ludum_DescribableMesh.__name__ = true;
ludum_DescribableMesh.__interfaces__ = [ludum_Describable];
ludum_DescribableMesh.__super__ = THREE.Mesh;
ludum_DescribableMesh.prototype = $extend(THREE.Mesh.prototype,{
	clickText: function(click) {
		if(this.clickMessages.length == 0) return this.hoverText;
		if(click > this.clickMessages.length) return ludum_Player.randomMessage(Std["int"](Math.random() * 3));
		return this.clickMessages[Std["int"](MathUtils.clamp(click,0,this.clickMessages.length - 1))];
	}
	,__class__: ludum_DescribableMesh
});
var ludum_Enemy = function(scene,x,y,hoverText,texture,particles,alive) {
	if(alive == null) alive = 1.0;
	if(particles == null) particles = 300;
	if(texture == null) texture = "assets/images/darkfly.png";
	if(hoverText == null) hoverText = "A vile spirit...";
	this.clickMessages = [];
	this.velocity = new THREE.Vector2();
	this.baseVelocity = 125;
	this.signal_Died = new msignal_Signal0();
	this.signal_PositionChanged = new msignal_Signal1();
	THREE.Mesh.call(this);
	this.hoverText = hoverText;
	this.position.set(x,y,-1400);
	this.particleGroup = new SPE.Group({ texture : THREE.ImageUtils.loadTexture(texture), maxAge : 5});
	this.particleEmitter = new SPE.Emitter({ type : "cube", position : this.position, acceleration : new THREE.Vector3(0,0,0), velocity : new THREE.Vector3(0,0,0), velocitySpread : new THREE.Vector3(7,3,0), accelerationSpread : new THREE.Vector3(21,30,0), particleCount : 700, sizeStart : 42, sizeEnd : 60, opacityStart : 0.9, opacityEnd : 0.0});
	this.name = "Enemy";
	this.particleGroup.mesh.name = "Enemy Particle Group";
	this.particleGroup.addEmitter(this.particleEmitter);
	this.particleGroup.mesh.frustumCulled = false;
	scene.add(this.particleGroup.mesh);
	scene.add(this);
};
ludum_Enemy.__name__ = true;
ludum_Enemy.__interfaces__ = [ludum_Describable];
ludum_Enemy.__super__ = THREE.Mesh;
ludum_Enemy.prototype = $extend(THREE.Mesh.prototype,{
	reset: function() {
		this.particleEmitter.position = this.position;
		this.particleEmitter.acceleration.set(0,0,0);
		this.particleEmitter.velocity.set(0,0,0);
		this.particleEmitter.velocitySpread.set(7,3,0);
		this.particleEmitter.accelerationSpread.set(21,30,0);
		this.particleEmitter.particleCount = 700;
		this.particleEmitter.sizeStart = 42;
		this.particleEmitter.sizeEnd = 60;
		this.particleEmitter.opacityStart = 0.9;
		this.particleEmitter.opacityEnd = 0.0;
	}
	,update: function(dt) {
		this.particleEmitter.position.set(this.position.x,this.position.y,this.position.z);
		this.particleGroup.tick(dt);
	}
	,clickText: function(click) {
		if(this.clickMessages.length == 0) return this.hoverText;
		if(click > this.clickMessages.length) return ludum_Player.randomMessage(Std["int"](Math.random() * 3));
		return this.clickMessages[Std["int"](MathUtils.clamp(click,0,this.clickMessages.length - 1))];
	}
	,__class__: ludum_Enemy
});
var ludum_Player = function(scene,x,y,width,height) {
	this.inputEnabled = true;
	this.velocity = new THREE.Vector2();
	this.baseVelocity = 125;
	this.pressedArrowKey = false;
	this.signal_Died = new msignal_Signal0();
	this.signal_PositionChanged = new msignal_Signal1();
	THREE.Mesh.call(this);
	this.position.set(x,y,-1400);
	width = 1000;
	height = 1000;
	this.particleGroup = new SPE.Group({ texture : THREE.ImageUtils.loadTexture("assets/images/flamefly.png"), maxAge : 5});
	this.particleEmitter = new SPE.Emitter({ type : "cube", position : this.position, acceleration : new THREE.Vector3(0,0,0), velocity : new THREE.Vector3(0,0,0), velocitySpread : new THREE.Vector3(10,10,10), particleCount : 3000, alive : 0.1, sizeStart : 12, sizeEnd : 42, opacityStart : 0.9, opacityEnd : 0});
	this.blastParticleGroup = new SPE.Group({ texture : THREE.ImageUtils.loadTexture("assets/images/flamefly.png"), maxAge : 5});
	this.blastParticleEmitter = new SPE.Emitter({ type : "cube", position : this.position, acceleration : new THREE.Vector3(0,0,0), velocity : new THREE.Vector3(0,0,0), velocitySpread : new THREE.Vector3(30,30,30), particleCount : 3000, sizeStart : 42, sizeEnd : 64, opacityStart : 0.5, opacityMiddle : 1.0, opacityEnd : 0, alive : 0.0});
	motion_Actuate.tween(this.particleEmitter.position,0.5,{ y : this.position.y + 40}).ease(motion_easing_Quad.get_easeOut()).repeat().reflect();
	this.name = "Player";
	this.particleGroup.mesh.name = "Player Particle Group";
	this.blastParticleGroup.mesh.name = "Player Blast Particle Group";
	this.particleGroup.addEmitter(this.particleEmitter);
	this.particleGroup.mesh.frustumCulled = false;
	scene.add(this.particleGroup.mesh);
	this.blastParticleGroup.addEmitter(this.blastParticleEmitter);
	this.blastParticleGroup.mesh.frustumCulled = false;
	scene.add(this.blastParticleGroup.mesh);
	scene.add(this);
};
ludum_Player.__name__ = true;
ludum_Player.randomMessage = function(parts) {
	if(parts == 0) return "...";
	var message = "";
	var _g = 0;
	while(_g < parts) {
		var i = _g++;
		message += "...*" + ludum_Player.vocabulary[Std["int"](Math.random() * (ludum_Player.vocabulary.length - 1))] + "*...";
	}
	return message;
};
ludum_Player.__super__ = THREE.Mesh;
ludum_Player.prototype = $extend(THREE.Mesh.prototype,{
	update: function(dt) {
		this.position.x += this.velocity.x * dt;
		this.position.y += this.velocity.y * dt;
		this.particleEmitter.position.x = this.position.x;
		this.particleEmitter.position.z = this.position.z;
		this.particleEmitter.velocity.x = -this.velocity.x * Math.random() * 0.02;
		this.particleEmitter.velocity.y = Math.random() * 50 - 1;
		this.particleGroup.tick(dt);
		this.blastParticleEmitter.position.set(this.position.x,this.position.y,this.position.z);
		this.blastParticleGroup.tick(dt);
		if(this.velocity.x != 0 || this.velocity.y != 0) this.signal_PositionChanged.dispatch(this.position);
	}
	,reset: function() {
		this.velocity.set(0,0);
		this.set_inputEnabled(true);
		this.baseVelocity = Math.min(this.baseVelocity,350);
		this.particleEmitter.alive = 0.1;
		this.particleEmitter.velocitySpread.set(10,10,10);
	}
	,setupInputEvents: function() {
		var _g = this;
		window.document.addEventListener("keydown",function(event) {
			if(!_g.inputEnabled) return;
			var keyCode = event.keyCode;
			switch(keyCode) {
			case 37:
				_g.velocity.x = -_g.baseVelocity;
				break;
			case 38:
				break;
			case 39:
				_g.velocity.x = _g.baseVelocity;
				break;
			case 40:
				break;
			default:
			}
		},false);
		window.document.addEventListener("keyup",function(event1) {
			if(!_g.inputEnabled) return;
			var keyCode1 = event1.keyCode;
			switch(keyCode1) {
			case 37:
				_g.velocity.x = 0;
				break;
			case 38:
				break;
			case 39:
				_g.velocity.x = 0;
				break;
			case 40:
				break;
			default:
			}
		},false);
	}
	,set_inputEnabled: function(enabled) {
		this.inputEnabled = enabled;
		this.velocity.set(0,0);
		return this.inputEnabled;
	}
	,__class__: ludum_Player
	,__properties__: {set_inputEnabled:"set_inputEnabled"}
});
var ludum_ScreenSwitcher = function() { };
ludum_ScreenSwitcher.__name__ = true;
ludum_ScreenSwitcher.checkForBoundaryCrossing = function(lastPosition,currentPosition) {
	var lastNearestBoundary = Math.round(lastPosition.x / 800) * 800 + 400.;
	var currentNearestBoundary = Math.round(currentPosition.x / 800) * 800 + 400.;
	if(lastNearestBoundary != currentNearestBoundary) return true;
	return false;
};
ludum_ScreenSwitcher.getScreenIndices = function(position) {
	return new THREE.Vector2(Math.round(position.x / 800),position.y / 500 | 0);
};
ludum_ScreenSwitcher.getNearestCameraClampX = function(position) {
	return Math.round(position.x / 800) * 800;
};
var ludum_screens_Screen = function(game,index,active) {
	if(active == null) active = false;
	this.enemies = [];
	this.index = index;
	this.set_active(active);
	this.game = game;
	this.firstEnter = true;
	this.firstExit = true;
};
ludum_screens_Screen.__name__ = true;
ludum_screens_Screen.findScreen = function(index,screens) {
	var _g_head = screens.h;
	var _g_val = null;
	while(_g_head != null) {
		var screen;
		screen = (function($this) {
			var $r;
			_g_val = _g_head[0];
			_g_head = _g_head[1];
			$r = _g_val;
			return $r;
		}(this));
		if(screen.index.x == index.x && screen.index.y == index.y) return screen;
	}
	return null;
};
ludum_screens_Screen.prototype = {
	skyEnterTransition: function() {
	}
	,permitsTransition: function(next) {
		return true;
	}
	,onEnter: function() {
		if(this.firstEnter) {
			this.onFirstEnter();
			this.firstEnter = false;
		}
		this.skyEnterTransition();
		console.log("Entering screen " + Std.string(this.index));
	}
	,onExit: function() {
		if(this.firstExit) {
			this.onFirstExit();
			this.firstExit = false;
		}
		console.log("Exiting screen " + Std.string(this.index));
	}
	,onFirstEnter: function() {
		console.log("Entering screen " + Std.string(this.index) + " for first time");
		this.game.player.baseVelocity += 15;
		this.game.player.particleEmitter.alive = Math.min(this.game.player.particleEmitter.alive + 0.05,1.0);
		this.game.player.particleEmitter.velocitySpread.addScalar(1.0);
	}
	,onFirstExit: function() {
		console.log("Exiting screen " + Std.string(this.index) + " for first time");
	}
	,update: function(dt) {
		if(!this.active) return;
		var _g = 0;
		var _g1 = this.enemies;
		while(_g < _g1.length) {
			var enemy = _g1[_g];
			++_g;
			enemy.particleEmitter.position.set(enemy.position.x,enemy.position.y,enemy.position.z);
			enemy.particleGroup.tick(dt);
		}
	}
	,reset: function() {
		this.firstEnter = true;
		this.firstExit = true;
		if(this.index.x != 0) this.set_active(false);
		var _g = 0;
		var _g1 = this.enemies;
		while(_g < _g1.length) {
			var enemy = _g1[_g];
			++_g;
			enemy.reset();
		}
	}
	,set_active: function(active) {
		if(this.active == active) return this.active;
		console.log("Setting screen " + Std.string(this.index) + " active = " + (active == null?"null":"" + active));
		return this.active = active;
	}
	,loadGround: function(imagePath,screenIndex,width,height) {
		if(height == null) height = 200;
		if(width == null) width = 800;
		var texture = THREE.ImageUtils.loadTexture(imagePath,THREE.UVMapping);
		texture.minFilter = THREE.NearestFilter;
		texture.magFilter = THREE.NearestFilter;
		var material = new THREE.MeshBasicMaterial({ map : texture, transparent : true, depthWrite : false, depthTest : false, opacity : 1.0});
		var geometry = new THREE.PlaneGeometry(width,height);
		var mesh = new THREE.Mesh(geometry,material);
		mesh.position.set(800 * screenIndex.x,-250. + height / 2,-1410);
		mesh.name = imagePath.substring(imagePath.lastIndexOf("/"));
		return mesh;
	}
	,loadBuilding: function(imagePath,screenIndex,xOffset,yOffset,width,height,hoverText,clickText,interactable) {
		if(interactable == null) interactable = true;
		if(hoverText == null) hoverText = "Building";
		var texture = THREE.ImageUtils.loadTexture(imagePath,THREE.UVMapping);
		texture.minFilter = THREE.NearestFilter;
		texture.magFilter = THREE.NearestFilter;
		var material = new THREE.MeshBasicMaterial({ map : texture, transparent : true, depthWrite : false, depthTest : false, opacity : 1.0});
		var geometry = new THREE.PlaneGeometry(width,height);
		var mesh = new ludum_DescribableMesh(geometry,material,hoverText,clickText);
		mesh.position.set(800 * screenIndex.x + xOffset,-250. + height / 2 + yOffset,-1410);
		mesh.name = hoverText;
		if(interactable) this.game.interactables.push(mesh);
		return mesh;
	}
	,positionItem: function(item,x,y,z) {
		if(z == null) z = -1410;
		item.position.set(800 * this.index.x + x,-250. + y,z);
	}
	,addGUIItems: function(gui) {
	}
	,__class__: ludum_screens_Screen
	,__properties__: {set_active:"set_active"}
};
var ludum_screens_RandomScreen = function(game,index,gameText,active) {
	if(active == null) active = false;
	if(gameText == null) gameText = "";
	this.graveDescriptions = [[""],[""],[""]];
	this.tombDescriptions = [[""],[""],[""]];
	this.templeDescriptions = [[""],[""],[""]];
	ludum_screens_Screen.call(this,game,index,active);
	this.gameText = gameText;
	if(index.x == 12) game.worldScene.add(this.loadGround("assets/images/ground5.png",index)); else if(index.x < 12) {
		var rand = Math.random();
		if(rand < 0.2) game.worldScene.add(this.loadGround("assets/images/ground1.png",index)); else if(rand < 0.4) game.worldScene.add(this.loadGround("assets/images/ground2.png",index)); else if(rand < 0.8) game.worldScene.add(this.loadGround("assets/images/ground3.png",index)); else game.worldScene.add(this.loadGround("assets/images/ground4.png",index));
	}
};
ludum_screens_RandomScreen.__name__ = true;
ludum_screens_RandomScreen.__super__ = ludum_screens_Screen;
ludum_screens_RandomScreen.prototype = $extend(ludum_screens_Screen.prototype,{
	onFirstEnter: function() {
		ludum_screens_Screen.prototype.onFirstEnter.call(this);
	}
	,onFirstExit: function() {
		ludum_screens_Screen.prototype.onFirstExit.call(this);
	}
	,onEnter: function() {
		ludum_screens_Screen.prototype.onEnter.call(this);
		if(!this.game.playerReturningToStart) this.game.setGameText(this.gameText,null,null,null,null);
	}
	,skyEnterTransition: function() {
		ludum_screens_Screen.prototype.skyEnterTransition.call(this);
		var _g = this.index.x;
		switch(_g) {
		case 3:
			this.sunup1();
			break;
		case 4:
			this.sunup2();
			break;
		case 5:
			this.sunup3();
			break;
		case 6:
			this.sunup4();
			break;
		case 7:
			this.sunup5();
			break;
		case 8:
			this.sunup6();
			break;
		case 9:
			this.night1();
			break;
		case 10:
			this.night2();
			break;
		case 11:
			this.hastening1();
			break;
		case 12:
			this.sea1();
			break;
		case 13:
			this.sea2();
			break;
		case 14:
			this.sea3();
			break;
		case 15:
			this.sea4();
			break;
		case 16:
			this.sea5();
			break;
		case 17:
			this.void1();
			break;
		case 18:
			this.void2();
			break;
		case 19:
			this.void3();
			break;
		case 20:
			this.void4();
			break;
		default:
			this.mutateSky();
		}
	}
	,onExit: function() {
		ludum_screens_Screen.prototype.onExit.call(this);
	}
	,reset: function() {
		ludum_screens_Screen.prototype.reset.call(this);
	}
	,update: function(dt) {
		ludum_screens_Screen.prototype.update.call(this,dt);
	}
	,sunup1: function() {
		var _g = this;
		motion_Actuate.tween(this.game.skyEffectController,3,{ turbidity : 2.075, rayleigh : 5.74, mieCoefficient : 0.005975, mieDirectionalG : 0.80, luminance : 1.10, inclination : 0.4895, azimuth : 0.2239, refractiveIndex : 1.000374, numMolecules : 2.442e25, depolarizationFactor : 0.12, rayleighZenithLength : 3480, mieV : 4.064, mieZenithLength : 8300, sunIntensityFactor : 1035, sunIntensityFalloffSteepness : 1.99, sunAngularDiameterDegrees : 0.012}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
	}
	,sunup2: function() {
		var _g = this;
		motion_Actuate.tween(this.game.skyEffectController,3,{ turbidity : 0.825, rayleigh : 7.455, mieCoefficient : 0.005975, mieDirectionalG : 0.536, luminance : 1.10, inclination : 0.4895, azimuth : 0.2171, refractiveIndex : 1.000374, numMolecules : 2.0e25, depolarizationFactor : 0.12, rayleighZenithLength : 3480, mieV : 4.034, mieZenithLength : 8300, sunIntensityFactor : 1380, sunIntensityFalloffSteepness : 1.99, sunAngularDiameterDegrees : 0.012}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
		motion_Actuate.tween(this.game.skyEffectController.cameraPos,3,{ y : -42000});
		this.game.starEmitter.alive = 0.25;
	}
	,sunup3: function() {
		var _g = this;
		motion_Actuate.tween(this.game.skyEffectController,3,{ turbidity : 4.025, rayleigh : 7.455, mieCoefficient : 0.005975, mieDirectionalG : 0.536, luminance : 1.1, inclination : 0.4895, azimuth : 0.2171, refractiveIndex : 1.000369, numMolecules : 2.542e25, depolarizationFactor : 0.12, rayleighZenithLength : 3480, mieV : 4.034, mieZenithLength : 2300, sunIntensityFactor : 1454, sunIntensityFalloffSteepness : 1.82, sunAngularDiameterDegrees : 0.0084}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
		motion_Actuate.tween(this.game.skyEffectController.cameraPos,3,{ y : 6000});
		this.game.starEmitter.alive = 0.25;
	}
	,sunup4: function() {
		var _g = this;
		motion_Actuate.tween(this.game.skyEffectController,3,{ turbidity : 5.825, rayleigh : 6.05, mieCoefficient : 0.017225, mieDirectionalG : 0.842, luminance : 1.0755, inclination : 0.4912, azimuth : 0.2171, refractiveIndex : 1.000295, numMolecules : 2.542e25, depolarizationFactor : 0.083, rayleighZenithLength : 3225, mieV : 4.003, mieZenithLength : 500, sunIntensityFactor : 1936, sunIntensityFalloffSteepness : 2.95, sunAngularDiameterDegrees : 0.01674}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
		motion_Actuate.tween(this.game.skyEffectController.cameraPos,3,{ y : -26750});
		this.game.starEmitter.alive = 0.0;
	}
	,sunup5: function() {
		var _g = this;
		motion_Actuate.tween(this.game.skyEffectController,3,{ turbidity : 5.825, rayleigh : 6.05, mieCoefficient : 0.017225, mieDirectionalG : 0.842, luminance : 1.0755, inclination : 0.4971, azimuth : 0.2171, refractiveIndex : 1.000295, numMolecules : 2.542e25, depolarizationFactor : 0.083, rayleighZenithLength : 8985, mieV : 4.003, mieZenithLength : 1000, sunIntensityFactor : 1936, sunIntensityFalloffSteepness : 2.95, sunAngularDiameterDegrees : 0.01674}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
		this.game.starEmitter.alive = 0.25;
	}
	,sunup6: function() {
		var _g = this;
		motion_Actuate.tween(this.game.skyEffectController,3,{ turbidity : 5.825, rayleigh : 6.05, mieCoefficient : 0.017225, mieDirectionalG : 0.842, luminance : 1.0755, inclination : 0.4986, azimuth : 0.2171, refractiveIndex : 1.000295, numMolecules : 2.542e25, depolarizationFactor : 0.083, rayleighZenithLength : 3630, mieV : 4.003, mieZenithLength : 1000, sunIntensityFactor : 1936, sunIntensityFalloffSteepness : 2.95, sunAngularDiameterDegrees : 0.01674}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
		this.game.starEmitter.alive = 0.15;
	}
	,night1: function() {
		var _g = this;
		motion_Actuate.tween(this.game.skyEffectController,3,{ turbidity : 4.7, rayleigh : 2.28, mieCoefficient : 0.005, mieDirectionalG : 0.82, luminance : 1.00, inclination : 0.5133, azimuth : 0.2361, refractiveIndex : 1.00029, numMolecules : 2.542e25, depolarizationFactor : 0.02, rayleighZenithLength : 8400, mieV : 3.936, mieZenithLength : 34000, sunIntensityFactor : 1000, sunIntensityFalloffSteepness : 1.5, sunAngularDiameterDegrees : 0.00933}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
		this.game.starEmitter.acceleration.set(32,-9,276);
		this.game.starEmitter.accelerationSpread.set(0,22,26);
		this.game.starEmitter.alive = 1.0;
	}
	,night2: function() {
		var _g = this;
		motion_Actuate.tween(this.game.skyEffectController,3,{ turbidity : 4.7, rayleigh : 2.28, mieCoefficient : 0.005, mieDirectionalG : 0.82, luminance : 1.00, inclination : 0.5133, azimuth : 0.2361, refractiveIndex : 1.00029, numMolecules : 2.542e25, depolarizationFactor : 0.02, rayleighZenithLength : 8400, mieV : 3.936, mieZenithLength : 34000, sunIntensityFactor : 1000, sunIntensityFalloffSteepness : 1.5, sunAngularDiameterDegrees : 0.00933}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
		this.game.starEmitter.acceleration.set(32,388,1235);
		this.game.starEmitter.accelerationSpread.set(0,342,564);
		motion_Actuate.tween(this.game.windEmitter,1,{ alive : 0.0});
		this.game.starEmitter.alive = 1.0;
	}
	,hastening1: function() {
		var _g = this;
		motion_Actuate.tween(this.game.skyEffectController,3,{ turbidity : 4.7, rayleigh : 2.28, mieCoefficient : 0.005, mieDirectionalG : 0.82, luminance : 1.00, inclination : 0.5133, azimuth : 0.2361, refractiveIndex : 1.00029, numMolecules : 2.542e25, depolarizationFactor : 0.02, rayleighZenithLength : 8400, mieV : 3.936, mieZenithLength : 34000, sunIntensityFactor : 1000, sunIntensityFalloffSteepness : 1.5, sunAngularDiameterDegrees : 0.00933}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
		this.game.starEmitter.acceleration.set(-40,0,0);
		this.game.starEmitter.accelerationSpread.set(20,0,0);
		motion_Actuate.tween(this.game.windEmitter,1,{ alive : 1.0});
		this.game.starEmitter.alive = 0.5;
	}
	,sea1: function() {
		var _g = this;
		motion_Actuate.tween(this.game.skyEffectController,3,{ turbidity : 4.7, rayleigh : 2.28, mieCoefficient : 0.005, mieDirectionalG : 0.82, luminance : 1.00, inclination : 0.5056, azimuth : 0.2721, refractiveIndex : 1.00029, numMolecules : 2.542e25, depolarizationFactor : 0.02, rayleighZenithLength : 9135, mieV : 3.936, mieZenithLength : 34000, sunIntensityFactor : 1000, sunIntensityFalloffSteepness : 1.5, sunAngularDiameterDegrees : 0.00933}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
		if(!this.game.playerReturningToStart) motion_Actuate.tween(this.game.skyEffectController.primaries,3,{ x : 6.8e-7, y : 5.5e-7, z : 4.5e-7}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
		motion_Actuate.tween(this.game.skyEffectController.cameraPos,3,{ y : -43250});
		this.game.starEmitter.acceleration.set(0,0,0);
		this.game.starEmitter.accelerationSpread.set(0,0,0);
		motion_Actuate.tween(this.game.windEmitter,3,{ alive : 0.0});
		this.game.starEmitter.alive = 1.0;
	}
	,sea2: function() {
		var _g = this;
		motion_Actuate.tween(this.game.skyEffectController,3,{ turbidity : 4.7, rayleigh : 2.28, mieCoefficient : 0.005, mieDirectionalG : 0.82, luminance : 1.00, inclination : 0.5056, azimuth : 0.2721, refractiveIndex : 1.000218, numMolecules : 2.542e25, depolarizationFactor : 0.02, rayleighZenithLength : 9135, mieV : 3.936, mieZenithLength : 34000, sunIntensityFactor : 1000, sunIntensityFalloffSteepness : 1.5, sunAngularDiameterDegrees : 0.00933}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
		if(!this.game.playerReturningToStart) motion_Actuate.tween(this.game.skyEffectController.primaries,3,{ x : 7.5e-7, y : 4.5e-7, z : 5.1e-7}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
		this.game.starEmitter.acceleration.set(0,0,0);
		this.game.starEmitter.accelerationSpread.set(0,0,0);
		this.game.starEmitter.alive = 1.0;
	}
	,sea3: function() {
		this.game.starEmitter.acceleration.set(32,388,435);
		this.game.starEmitter.accelerationSpread.set(0,342,164);
		this.game.starEmitter.alive = 1.0;
	}
	,sea4: function() {
		var _g = this;
		motion_Actuate.tween(this.game.skyEffectController,3,{ turbidity : 4.7, rayleigh : 2.28, mieCoefficient : 0.005, mieDirectionalG : 0.82, luminance : 1.00, inclination : 0.5080, azimuth : 0.2721, refractiveIndex : 1.000218, numMolecules : 2.542e25, depolarizationFactor : 0.02, rayleighZenithLength : 9135, mieV : 3.936, mieZenithLength : 34000, sunIntensityFactor : 1000, sunIntensityFalloffSteepness : 1.5, sunAngularDiameterDegrees : 0.00933}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
		this.game.starEmitter.acceleration.set(32,388,835);
		this.game.starEmitter.accelerationSpread.set(0,342,364);
		this.game.starEmitter.alive = 1.0;
	}
	,sea5: function() {
		var _g = this;
		motion_Actuate.tween(this.game.skyEffectController,3,{ turbidity : 4.7, rayleigh : 2.28, mieCoefficient : 0.005, mieDirectionalG : 0.82, luminance : 1.00, inclination : 0.5110, azimuth : 0.2721, refractiveIndex : 1.000218, numMolecules : 2.542e25, depolarizationFactor : 0.02, rayleighZenithLength : 9135, mieV : 3.936, mieZenithLength : 34000, sunIntensityFactor : 1000, sunIntensityFalloffSteepness : 1.5, sunAngularDiameterDegrees : 0.00933}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
		this.game.starEmitter.acceleration.set(32,388,1235);
		this.game.starEmitter.accelerationSpread.set(0,342,564);
		this.game.starEmitter.alive = 1.0;
	}
	,void1: function() {
		var _g = this;
		motion_Actuate.tween(this.game.skyEffectController,3,{ turbidity : 4.7, rayleigh : 2.28, mieCoefficient : 0.005, mieDirectionalG : 0.82, luminance : 1.00, inclination : 0.5154, azimuth : 0.2721, refractiveIndex : 1.000218, numMolecules : 2.542e25, depolarizationFactor : 0.02, rayleighZenithLength : 9135, mieV : 3.936, mieZenithLength : 34000, sunIntensityFactor : 1000, sunIntensityFalloffSteepness : 1.5, sunAngularDiameterDegrees : 0.00933}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
		this.game.starEmitter.acceleration.set(32,388,835);
		this.game.starEmitter.accelerationSpread.set(0,342,364);
		this.game.starEmitter.alive = 1.0;
	}
	,void2: function() {
		this.game.starEmitter.acceleration.set(32,388,435);
		this.game.starEmitter.accelerationSpread.set(0,342,164);
		this.game.starEmitter.alive = 1.0;
	}
	,void3: function() {
		this.game.starEmitter.acceleration.set(0,0,0);
		this.game.starEmitter.accelerationSpread.set(0,0,0);
		this.game.starEmitter.alive = 1.0;
	}
	,void4: function() {
		this.game.starEmitter.acceleration.set(0,0,0);
		this.game.starEmitter.accelerationSpread.set(0,0,0);
		this.game.starEmitter.alive = 1.0;
	}
	,mutateSky: function() {
		var _g = this;
		motion_Actuate.tween(this.game.skyEffectController,3,{ turbidity : 7.25, rayleigh : 4.815, mieCoefficient : 0.005975, mieDirectionalG : 0.80, luminance : 1.00, inclination : 0.4935, azimuth : 0.2361, refractiveIndex : 1.000369, numMolecules : 2.542e25, depolarizationFactor : 0.091, rayleighZenithLength : 3330, mieV : 3.956, mieZenithLength : -16900, sunIntensityFactor : 1069, sunIntensityFalloffSteepness : 1.05, sunAngularDiameterDegrees : 0.012}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
		motion_Actuate.tween(this.game.skyEffectController.cameraPos,3,{ y : -42000});
		if(Math.random() < 0.5) this.game.starEmitter.accelerationSpread.set(Math.random() * 5,Math.random() * 5,0); else this.game.starEmitter.accelerationSpread.set(0,0,0);
	}
	,__class__: ludum_screens_RandomScreen
});
var ludum_screens_ScreenFour = function(game,index,active) {
	if(active == null) active = false;
	this.gameOverTriggered = false;
	this.godTalkTextIndex = 0;
	ludum_screens_Screen.call(this,game,index,active);
	game.worldScene.add(this.loadGround("assets/images/ground3.png",index));
	this.visnu = new ludum_Enemy(game.worldScene,0,0,"God of Earth","assets/images/earthfly.png",3000,0.1);
	this.varuna = new ludum_Enemy(game.worldScene,0,0,"God of Water","assets/images/icefly.png",3000,0.1);
	this.vayu = new ludum_Enemy(game.worldScene,0,0,"God of Air","assets/images/airfly.png",3000,0.1);
	this.positionItem(this.visnu,-250,300);
	this.positionItem(this.varuna,0,300);
	this.positionItem(this.vayu,250,300);
	this.enemies.push(this.visnu);
	this.enemies.push(this.varuna);
	this.enemies.push(this.vayu);
	var _g = 0;
	var _g1 = this.enemies;
	while(_g < _g1.length) {
		var enemy = _g1[_g];
		++_g;
		enemy.particleEmitter.alive = 0;
		enemy.particleEmitter.accelerationSpread.set(8,8,0);
	}
	game.signal_playerClicked.add($bind(this,this.advanceText));
};
ludum_screens_ScreenFour.__name__ = true;
ludum_screens_ScreenFour.__super__ = ludum_screens_Screen;
ludum_screens_ScreenFour.prototype = $extend(ludum_screens_Screen.prototype,{
	permitsTransition: function(next) {
		return false;
	}
	,onFirstEnter: function() {
		ludum_screens_Screen.prototype.onFirstEnter.call(this);
		this.advanceText(0,0);
		var _g = 0;
		var _g1 = this.enemies;
		while(_g < _g1.length) {
			var enemy = _g1[_g];
			++_g;
			enemy.particleEmitter.alive = 1.0;
			enemy.particleEmitter.accelerationSpread.set(8,8,0);
		}
	}
	,onFirstExit: function() {
		ludum_screens_Screen.prototype.onFirstExit.call(this);
	}
	,skyEnterTransition: function() {
		ludum_screens_Screen.prototype.skyEnterTransition.call(this);
	}
	,onEnter: function() {
		ludum_screens_Screen.prototype.onEnter.call(this);
	}
	,onExit: function() {
		ludum_screens_Screen.prototype.onExit.call(this);
	}
	,reset: function() {
		ludum_screens_Screen.prototype.reset.call(this);
		this.godTalkTextIndex = 0;
		this.gameOverTriggered = false;
		var _g = 0;
		var _g1 = this.enemies;
		while(_g < _g1.length) {
			var enemy = _g1[_g];
			++_g;
			enemy.particleEmitter.alive = 0.0;
		}
	}
	,update: function(dt) {
		ludum_screens_Screen.prototype.update.call(this,dt);
	}
	,addGUIItems: function(gui) {
	}
	,advanceText: function(x,y) {
		var _g = this;
		if(this.active) {
			if(this.godTalkTextIndex > ludum_screens_ScreenFour.godTalk.length - 1 && !this.game.playerReturningToStart && !this.gameOverTriggered) {
				this.gameOverTriggered = true;
				this.visnu.particleEmitter.acceleration.set(65,-15,351);
				this.visnu.particleEmitter.accelerationSpread.set(43,41,61);
				this.varuna.particleEmitter.acceleration.set(0,-14,262);
				this.varuna.particleEmitter.accelerationSpread.set(21,30,0);
				this.vayu.particleEmitter.acceleration.set(-65,-15,351);
				this.vayu.particleEmitter.accelerationSpread.set(43,41,61);
				this.game.setGameText("Arrrrrghhhh! Noooooooooooooooooooooo....",null,3,null,null);
				motion_Actuate.tween(this.game.player.particleEmitter,1,{ alive : 0.1});
				motion_Actuate.tween(this.game.skyEffectController.primaries,1,{ x : 6.8e-7, y : 4.5e-7, z : 4.5e-7}).onUpdate(function() {
					_g.game.skyEffectController.updateUniforms();
				});
				this.game.starEmitter.opacityMiddle = 1.0;
				this.game.starEmitter.acceleration.set(0,0,830);
				this.game.starEmitter.accelerationSpread.set(0,0,560);
				this.game.starEmitter.alive = 1.0;
				motion_Actuate.tween(this.visnu.particleEmitter,3,{ alive : 1.0}).onUpdate(function() {
					_g.varuna.particleEmitter.alive = _g.visnu.particleEmitter.alive;
					_g.vayu.particleEmitter.alive = _g.visnu.particleEmitter.alive;
				}).onComplete(function() {
					_g.game.player.signal_Died.dispatch();
				});
			} else if(this.godTalkTextIndex <= ludum_screens_ScreenFour.godTalk.length - 1) {
				this.game.setGameText(ludum_screens_ScreenFour.godTalk[this.godTalkTextIndex].text,ludum_screens_ScreenFour.godTalk[this.godTalkTextIndex].color,null,null,null);
				this.godTalkTextIndex++;
			}
		}
	}
	,__class__: ludum_screens_ScreenFour
});
var ludum_screens_ScreenOne = function(game,index,active) {
	if(active == null) active = false;
	ludum_screens_Screen.call(this,game,index,active);
	game.worldScene.add(this.loadGround("assets/images/ground1.png",index));
	this.spiritCross = this.loadBuilding("assets/images/crosses0.png",index,180,118,110,81,"Burial Ground",["That vile spirit rose from here...","The inscription on the stone has been scorched away...","...","......"]);
	game.worldScene.add(this.spiritCross);
	game.worldScene.add(this.loadBuilding("assets/images/cross0.png",index,-180,118,100,110,"Ruined Tombstone",["A charred grave marker, covered in ash...","The inscription has been destroyed by flame..."]));
	game.worldScene.add(this.loadBuilding("assets/images/tomb1.png",index,280,118,100,110,"Scorched Altar",["A runic engraving in the sept reads...","'Vocatus atque non vocatus, Deus aderit'...","...","It's coming back now... yes...","...","...I was a God, that I was...","But where are my disciples...?"]));
	this.spirit = new ludum_Enemy(game.worldScene,this.spiritCross.position.x,this.spiritCross.position.y);
	game.worldScene.add(this.spirit);
	this.enemies.push(this.spirit);
	game.interactables.push(this.spirit);
	this.spiritDied = false;
	this.spirit.signal_Died.add($bind(this,this.onSpiritDied));
};
ludum_screens_ScreenOne.__name__ = true;
ludum_screens_ScreenOne.__super__ = ludum_screens_Screen;
ludum_screens_ScreenOne.prototype = $extend(ludum_screens_Screen.prototype,{
	permitsTransition: function(next) {
		return this.spiritDied;
	}
	,reset: function() {
		ludum_screens_Screen.prototype.reset.call(this);
		this.spiritDied = false;
		this.spirit.position.x = this.spiritCross.position.x;
		this.spirit.position.y = this.spiritCross.position.y;
		this.spirit.particleEmitter.alive = 1.0;
	}
	,onSpiritDied: function() {
		this.spiritDied = true;
		this.game.setGameText("*Explodes*","#5555FF",0.5,null,null);
		this.game.player.set_inputEnabled(true);
		this.game.raycastingEnabled = true;
	}
	,onFirstEnter: function() {
		var _g = this;
		ludum_screens_Screen.prototype.onFirstEnter.call(this);
		this.spirit.position.x = this.spiritCross.position.x;
		this.game.raycastingEnabled = false;
		this.game.setGameText("Return to the darkness!","#5555FF",null,null,null);
		motion_Actuate.tween(this.spirit.position,1,{ y : 100}).delay(2.5).onUpdate(function() {
		}).onComplete(function() {
			_g.game.setGameText("A mere spirit means to command me? Die... NOW.",null,null,null,null);
			_g.game.player.blastParticleEmitter.acceleration.x = 31;
			_g.game.player.blastParticleEmitter.velocity.set(99,86,0);
			_g.game.player.blastParticleEmitter.velocitySpread.set(26,22,30);
			_g.game.player.blastParticleEmitter.accelerationSpread.set(143,15,0);
			motion_Actuate.tween(_g.game.player.blastParticleEmitter,2,{ alive : 1.0}).onComplete(function() {
				motion_Actuate.tween(_g.game.player.blastParticleEmitter,0.5,{ alive : 0.0});
			});
			motion_Actuate.tween(_g.spirit.particleEmitter,2,{ alive : 0.0}).delay(2.0).onUpdate(function() {
				_g.spirit.particleEmitter.acceleration.set(85,36,0);
				_g.spirit.particleEmitter.accelerationSpread.set(200.6,294,0);
				_g.game.restoreSkyToDefaults(8,0.4949,0.1981);
				_g.game.restoreStarsToDefaults();
			}).onComplete(function() {
				_g.spirit.signal_Died.dispatch();
			});
		});
	}
	,onFirstExit: function() {
		ludum_screens_Screen.prototype.onFirstExit.call(this);
	}
	,skyEnterTransition: function() {
		var _g = this;
		ludum_screens_Screen.prototype.skyEnterTransition.call(this);
		motion_Actuate.tween(this.game.skyEffectController,3,{ turbidity : 1.0, rayleigh : 3.25, mieCoefficient : 0.005975, mieDirectionalG : 0.80, luminance : 1.00, inclination : 0.4742, azimuth : 0.2268, refractiveIndex : 1.000266, numMolecules : 2.542e25, depolarizationFactor : 0.091, rayleighZenithLength : 570, mieV : 3.961, mieZenithLength : 2400, sunIntensityFactor : 1024, sunIntensityFalloffSteepness : 1.4, sunAngularDiameterDegrees : 0.00600}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
		this.game.starEmitter.opacityMiddle = 1.0;
		this.game.starEmitter.acceleration.set(0,0,830);
		this.game.starEmitter.accelerationSpread.set(0,0,560);
		this.game.starEmitter.alive = 1.0;
	}
	,onEnter: function() {
		ludum_screens_Screen.prototype.onEnter.call(this);
	}
	,onExit: function() {
		ludum_screens_Screen.prototype.onExit.call(this);
		this.game.restoreStarsToDefaults();
	}
	,update: function(dt) {
		ludum_screens_Screen.prototype.update.call(this,dt);
	}
	,addGUIItems: function(gui) {
	}
	,__class__: ludum_screens_ScreenOne
});
var ludum_screens_ScreenThree = function(game,index,active) {
	if(active == null) active = false;
	ludum_screens_Screen.call(this,game,index,active);
	game.worldScene.add(this.loadGround("assets/images/ground6.png",index));
};
ludum_screens_ScreenThree.__name__ = true;
ludum_screens_ScreenThree.__super__ = ludum_screens_Screen;
ludum_screens_ScreenThree.prototype = $extend(ludum_screens_Screen.prototype,{
	onFirstEnter: function() {
		ludum_screens_Screen.prototype.onFirstEnter.call(this);
	}
	,onFirstExit: function() {
		ludum_screens_Screen.prototype.onFirstExit.call(this);
	}
	,skyEnterTransition: function() {
		var _g = this;
		ludum_screens_Screen.prototype.skyEnterTransition.call(this);
		motion_Actuate.tween(this.game.skyEffectController,3,{ turbidity : 4.7, rayleigh : 2.28, mieCoefficient : 0.005, mieDirectionalG : 0.82, luminance : 1.00, inclination : 0.5154, azimuth : 0.2721, refractiveIndex : 1.000218, numMolecules : 2.542e25, depolarizationFactor : 0.02, rayleighZenithLength : 9135, mieV : 3.936, mieZenithLength : 34000, sunIntensityFactor : 1000, sunIntensityFalloffSteepness : 1.5, sunAngularDiameterDegrees : 0.00933}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
		motion_Actuate.tween(this.game.skyEffectController.cameraPos,3,{ x : 100000, y : -42000, z : -219500});
	}
	,onEnter: function() {
		ludum_screens_Screen.prototype.onEnter.call(this);
	}
	,onExit: function() {
		ludum_screens_Screen.prototype.onExit.call(this);
	}
	,reset: function() {
		ludum_screens_Screen.prototype.reset.call(this);
	}
	,update: function(dt) {
		ludum_screens_Screen.prototype.update.call(this,dt);
	}
	,addGUIItems: function(gui) {
	}
	,__class__: ludum_screens_ScreenThree
});
var ludum_screens_ScreenTwo = function(game,index,active) {
	if(active == null) active = false;
	ludum_screens_Screen.call(this,game,index,active);
	game.worldScene.add(this.loadGround("assets/images/ground2.png",index));
};
ludum_screens_ScreenTwo.__name__ = true;
ludum_screens_ScreenTwo.__super__ = ludum_screens_Screen;
ludum_screens_ScreenTwo.prototype = $extend(ludum_screens_Screen.prototype,{
	onFirstEnter: function() {
		ludum_screens_Screen.prototype.onFirstEnter.call(this);
	}
	,onFirstExit: function() {
		ludum_screens_Screen.prototype.onFirstExit.call(this);
	}
	,skyEnterTransition: function() {
		ludum_screens_Screen.prototype.skyEnterTransition.call(this);
	}
	,onEnter: function() {
		ludum_screens_Screen.prototype.onEnter.call(this);
	}
	,onExit: function() {
		ludum_screens_Screen.prototype.onExit.call(this);
	}
	,reset: function() {
		ludum_screens_Screen.prototype.reset.call(this);
	}
	,update: function(dt) {
		ludum_screens_Screen.prototype.update.call(this,dt);
	}
	,addGUIItems: function(gui) {
	}
	,__class__: ludum_screens_ScreenTwo
});
var ludum_screens_ScreenZero = function(game,index,active) {
	if(active == null) active = false;
	ludum_screens_Screen.call(this,game,index,active);
	this.starGroup = new SPE.Group({ texture : THREE.ImageUtils.loadTexture("assets/images/firefly.png"), maxAge : 5});
	this.starEmitter = new SPE.Emitter({ type : "cube", position : new THREE.Vector3(-25,0,-1417), positionSpread : new THREE.Vector3(808,426,0), acceleration : new THREE.Vector3(6.7,5,63), accelerationSpread : new THREE.Vector3(3.9,4,0), velocity : new THREE.Vector3(-101,0,0), velocitySpread : new THREE.Vector3(7,0,0), sizeStart : 10, sizeEnd : 10, opacityStart : 0, opacityMiddle : 1, opacityEnd : 0, particleCount : 5000});
	this.starGroup.addEmitter(this.starEmitter);
	this.starGroup.mesh.frustumCulled = false;
	game.worldScene.add(this.starGroup.mesh);
	game.worldScene.add(this.loadGround("assets/images/ground0.png",index));
	game.worldScene.add(this.loadBuilding("assets/images/temple0.png",index,80,118,100,110,"Temple of Flame",["A charred husk of a temple...","...","The dust lays thick on the floors and chokes the air","......","A worn inscription at the main altar reads 'Requiem aeternam dona ei, Agni'...","..."]));
	game.worldScene.add(this.loadBuilding("assets/images/tomb0.png",index,280,118,100,110,"Sepulchre of Cinders",["A monument dedicated to a God...","The inscription on the altar has worn away.","...","I should look around and collect my thoughts...","..."]));
};
ludum_screens_ScreenZero.__name__ = true;
ludum_screens_ScreenZero.__super__ = ludum_screens_Screen;
ludum_screens_ScreenZero.prototype = $extend(ludum_screens_Screen.prototype,{
	skyEnterTransition: function() {
		var _g = this;
		ludum_screens_Screen.prototype.skyEnterTransition.call(this);
		motion_Actuate.tween(this.game.skyEffectController,3,{ turbidity : 4.7, rayleigh : 2.28, mieCoefficient : 0.005, mieDirectionalG : 0.82, luminance : 1.00, inclination : 0.4983, azimuth : 0.1979, refractiveIndex : 1.00029, numMolecules : 2.542e25, depolarizationFactor : 0.02, rayleighZenithLength : 8400, mieV : 3.936, mieZenithLength : 34000, sunIntensityFactor : 1000, sunIntensityFalloffSteepness : 1.5, sunAngularDiameterDegrees : 0.00933}).onUpdate(function() {
			_g.game.skyEffectController.updateUniforms();
		});
		this.game.starEmitter.accelerationSpread.set(50,50,0);
	}
	,onEnter: function() {
		ludum_screens_Screen.prototype.onEnter.call(this);
	}
	,onExit: function() {
		ludum_screens_Screen.prototype.onExit.call(this);
	}
	,onFirstEnter: function() {
		ludum_screens_Screen.prototype.onFirstEnter.call(this);
	}
	,onFirstExit: function() {
		ludum_screens_Screen.prototype.onFirstExit.call(this);
	}
	,update: function(dt) {
		ludum_screens_Screen.prototype.update.call(this,dt);
		this.starGroup.tick(dt);
	}
	,addGUIItems: function(gui) {
		this.game.addGUIItem(this.game.particleGUI.addFolder("Screen Zero Star Emitter"),this.starEmitter,"Screen Zero Star Emitter");
	}
	,__class__: ludum_screens_ScreenZero
});
var motion_actuators_IGenericActuator = function() { };
motion_actuators_IGenericActuator.__name__ = true;
motion_actuators_IGenericActuator.prototype = {
	__class__: motion_actuators_IGenericActuator
};
var motion_actuators_GenericActuator = function(target,duration,properties) {
	this._autoVisible = true;
	this._delay = 0;
	this._reflect = false;
	this._repeat = 0;
	this._reverse = false;
	this._smartRotation = false;
	this._snapping = false;
	this.special = false;
	this.target = target;
	this.properties = properties;
	this.duration = duration;
	this._ease = motion_Actuate.defaultEase;
};
motion_actuators_GenericActuator.__name__ = true;
motion_actuators_GenericActuator.__interfaces__ = [motion_actuators_IGenericActuator];
motion_actuators_GenericActuator.prototype = {
	apply: function() {
		var _g = 0;
		var _g1 = Reflect.fields(this.properties);
		while(_g < _g1.length) {
			var i = _g1[_g];
			++_g;
			if(Object.prototype.hasOwnProperty.call(this.target,i)) Reflect.setField(this.target,i,Reflect.field(this.properties,i)); else Reflect.setProperty(this.target,i,Reflect.field(this.properties,i));
		}
	}
	,autoVisible: function(value) {
		if(value == null) value = true;
		this._autoVisible = value;
		return this;
	}
	,callMethod: function(method,params) {
		if(params == null) params = [];
		return Reflect.callMethod(method,method,params);
	}
	,change: function() {
		if(this._onUpdate != null) this.callMethod(this._onUpdate,this._onUpdateParams);
	}
	,complete: function(sendEvent) {
		if(sendEvent == null) sendEvent = true;
		if(sendEvent) {
			this.change();
			if(this._onComplete != null) this.callMethod(this._onComplete,this._onCompleteParams);
		}
		motion_Actuate.unload(this);
	}
	,delay: function(duration) {
		this._delay = duration;
		return this;
	}
	,ease: function(easing) {
		this._ease = easing;
		return this;
	}
	,move: function() {
	}
	,onComplete: function(handler,parameters) {
		this._onComplete = handler;
		if(parameters == null) this._onCompleteParams = []; else this._onCompleteParams = parameters;
		if(this.duration == 0) this.complete();
		return this;
	}
	,onRepeat: function(handler,parameters) {
		this._onRepeat = handler;
		if(parameters == null) this._onRepeatParams = []; else this._onRepeatParams = parameters;
		return this;
	}
	,onUpdate: function(handler,parameters) {
		this._onUpdate = handler;
		if(parameters == null) this._onUpdateParams = []; else this._onUpdateParams = parameters;
		return this;
	}
	,onPause: function(handler,parameters) {
		this._onPause = handler;
		if(parameters == null) this._onPauseParams = []; else this._onPauseParams = parameters;
		return this;
	}
	,onResume: function(handler,parameters) {
		this._onResume = handler;
		if(parameters == null) this._onResumeParams = []; else this._onResumeParams = parameters;
		return this;
	}
	,pause: function() {
		if(this._onPause != null) this.callMethod(this._onPause,this._onPauseParams);
	}
	,reflect: function(value) {
		if(value == null) value = true;
		this._reflect = value;
		this.special = true;
		return this;
	}
	,repeat: function(times) {
		if(times == null) times = -1;
		this._repeat = times;
		return this;
	}
	,resume: function() {
		if(this._onResume != null) this.callMethod(this._onResume,this._onResumeParams);
	}
	,reverse: function(value) {
		if(value == null) value = true;
		this._reverse = value;
		this.special = true;
		return this;
	}
	,smartRotation: function(value) {
		if(value == null) value = true;
		this._smartRotation = value;
		this.special = true;
		return this;
	}
	,snapping: function(value) {
		if(value == null) value = true;
		this._snapping = value;
		this.special = true;
		return this;
	}
	,stop: function(properties,complete,sendEvent) {
	}
	,__class__: motion_actuators_GenericActuator
};
var motion_actuators_SimpleActuator = function(target,duration,properties) {
	this.active = true;
	this.propertyDetails = [];
	this.sendChange = false;
	this.paused = false;
	this.cacheVisible = false;
	this.initialized = false;
	this.setVisible = false;
	this.toggleVisible = false;
	this.startTime = haxe_Timer.stamp();
	motion_actuators_GenericActuator.call(this,target,duration,properties);
	if(!motion_actuators_SimpleActuator.addedEvent) {
		motion_actuators_SimpleActuator.addedEvent = true;
		motion_actuators_SimpleActuator.timer = new haxe_Timer(33);
		motion_actuators_SimpleActuator.timer.run = motion_actuators_SimpleActuator.stage_onEnterFrame;
	}
};
motion_actuators_SimpleActuator.__name__ = true;
motion_actuators_SimpleActuator.stage_onEnterFrame = function() {
	var currentTime = haxe_Timer.stamp();
	var actuator;
	var j = 0;
	var cleanup = false;
	var _g1 = 0;
	var _g = motion_actuators_SimpleActuator.actuatorsLength;
	while(_g1 < _g) {
		var i = _g1++;
		actuator = motion_actuators_SimpleActuator.actuators[j];
		if(actuator != null && actuator.active) {
			if(currentTime >= actuator.timeOffset) actuator.update(currentTime);
			j++;
		} else {
			motion_actuators_SimpleActuator.actuators.splice(j,1);
			--motion_actuators_SimpleActuator.actuatorsLength;
		}
	}
};
motion_actuators_SimpleActuator.__super__ = motion_actuators_GenericActuator;
motion_actuators_SimpleActuator.prototype = $extend(motion_actuators_GenericActuator.prototype,{
	setField_motion_actuators_MotionPathActuator_T: function(target,propertyName,value) {
		if(Object.prototype.hasOwnProperty.call(target,propertyName)) target[propertyName] = value; else Reflect.setProperty(target,propertyName,value);
	}
	,setField_motion_actuators_SimpleActuator_T: function(target,propertyName,value) {
		if(Object.prototype.hasOwnProperty.call(target,propertyName)) target[propertyName] = value; else Reflect.setProperty(target,propertyName,value);
	}
	,autoVisible: function(value) {
		if(value == null) value = true;
		this._autoVisible = value;
		if(!value) {
			this.toggleVisible = false;
			if(this.setVisible) this.setField_motion_actuators_SimpleActuator_T(this.target,"visible",this.cacheVisible);
		}
		return this;
	}
	,delay: function(duration) {
		this._delay = duration;
		this.timeOffset = this.startTime + duration;
		return this;
	}
	,getField: function(target,propertyName) {
		var value = null;
		if(Object.prototype.hasOwnProperty.call(target,propertyName)) value = Reflect.field(target,propertyName); else value = Reflect.getProperty(target,propertyName);
		return value;
	}
	,initialize: function() {
		var details;
		var start;
		var _g = 0;
		var _g1 = Reflect.fields(this.properties);
		while(_g < _g1.length) {
			var i = _g1[_g];
			++_g;
			var isField = true;
			if(Object.prototype.hasOwnProperty.call(this.target,i)) start = Reflect.field(this.target,i); else {
				isField = false;
				start = Reflect.getProperty(this.target,i);
			}
			if(typeof(start) == "number") {
				var value = this.getField(this.properties,i);
				if(start == null) start = 0;
				if(value == null) value = 0;
				details = new motion_actuators_PropertyDetails(this.target,i,start,value - start,isField);
				this.propertyDetails.push(details);
			}
		}
		this.detailsLength = this.propertyDetails.length;
		this.initialized = true;
	}
	,move: function() {
		this.toggleVisible = Object.prototype.hasOwnProperty.call(this.properties,"alpha") && Object.prototype.hasOwnProperty.call(this.properties,"visible");
		if(this.toggleVisible && this.properties.alpha != 0 && !this.getField(this.target,"visible")) {
			this.setVisible = true;
			this.cacheVisible = this.getField(this.target,"visible");
			this.setField_motion_actuators_SimpleActuator_T(this.target,"visible",true);
		}
		this.timeOffset = this.startTime;
		motion_actuators_SimpleActuator.actuators.push(this);
		++motion_actuators_SimpleActuator.actuatorsLength;
	}
	,onUpdate: function(handler,parameters) {
		this._onUpdate = handler;
		if(parameters == null) this._onUpdateParams = []; else this._onUpdateParams = parameters;
		this.sendChange = true;
		return this;
	}
	,pause: function() {
		if(!this.paused) {
			this.paused = true;
			motion_actuators_GenericActuator.prototype.pause.call(this);
			this.pauseTime = haxe_Timer.stamp();
		}
	}
	,resume: function() {
		if(this.paused) {
			this.paused = false;
			this.timeOffset += haxe_Timer.stamp() - this.pauseTime;
			motion_actuators_GenericActuator.prototype.resume.call(this);
		}
	}
	,setProperty: function(details,value) {
		if(details.isField) details.target[details.propertyName] = value; else Reflect.setProperty(details.target,details.propertyName,value);
	}
	,stop: function(properties,complete,sendEvent) {
		if(this.active) {
			if(properties == null) {
				this.active = false;
				if(complete) this.apply();
				this.complete(sendEvent);
				return;
			}
			var _g = 0;
			var _g1 = Reflect.fields(properties);
			while(_g < _g1.length) {
				var i = _g1[_g];
				++_g;
				if(Object.prototype.hasOwnProperty.call(this.properties,i)) {
					this.active = false;
					if(complete) this.apply();
					this.complete(sendEvent);
					return;
				}
			}
		}
	}
	,update: function(currentTime) {
		if(!this.paused) {
			var details;
			var easing;
			var i;
			var tweenPosition = (currentTime - this.timeOffset) / this.duration;
			if(tweenPosition > 1) tweenPosition = 1;
			if(!this.initialized) this.initialize();
			if(!this.special) {
				easing = this._ease.calculate(tweenPosition);
				var _g1 = 0;
				var _g = this.detailsLength;
				while(_g1 < _g) {
					var i1 = _g1++;
					details = this.propertyDetails[i1];
					this.setProperty(details,details.start + details.change * easing);
				}
			} else {
				if(!this._reverse) easing = this._ease.calculate(tweenPosition); else easing = this._ease.calculate(1 - tweenPosition);
				var endValue;
				var _g11 = 0;
				var _g2 = this.detailsLength;
				while(_g11 < _g2) {
					var i2 = _g11++;
					details = this.propertyDetails[i2];
					if(this._smartRotation && (details.propertyName == "rotation" || details.propertyName == "rotationX" || details.propertyName == "rotationY" || details.propertyName == "rotationZ")) {
						var rotation = details.change % 360;
						if(rotation > 180) rotation -= 360; else if(rotation < -180) rotation += 360;
						endValue = details.start + rotation * easing;
					} else endValue = details.start + details.change * easing;
					if(!this._snapping) {
						if(details.isField) details.target[details.propertyName] = endValue; else Reflect.setProperty(details.target,details.propertyName,endValue);
					} else this.setProperty(details,Math.round(endValue));
				}
			}
			if(tweenPosition == 1) {
				if(this._repeat == 0) {
					this.active = false;
					if(this.toggleVisible && this.getField(this.target,"alpha") == 0) this.setField_motion_actuators_SimpleActuator_T(this.target,"visible",false);
					this.complete(true);
					return;
				} else {
					if(this._onRepeat != null) this.callMethod(this._onRepeat,this._onRepeatParams);
					if(this._reflect) this._reverse = !this._reverse;
					this.startTime = currentTime;
					this.timeOffset = this.startTime + this._delay;
					if(this._repeat > 0) this._repeat--;
				}
			}
			if(this.sendChange) this.change();
		}
	}
	,__class__: motion_actuators_SimpleActuator
});
var motion_easing_Expo = function() { };
motion_easing_Expo.__name__ = true;
motion_easing_Expo.__properties__ = {get_easeOut:"get_easeOut",get_easeInOut:"get_easeInOut",get_easeIn:"get_easeIn"}
motion_easing_Expo.get_easeIn = function() {
	return new motion_easing_ExpoEaseIn();
};
motion_easing_Expo.get_easeInOut = function() {
	return new motion_easing_ExpoEaseInOut();
};
motion_easing_Expo.get_easeOut = function() {
	return new motion_easing_ExpoEaseOut();
};
var motion_easing_IEasing = function() { };
motion_easing_IEasing.__name__ = true;
motion_easing_IEasing.prototype = {
	__class__: motion_easing_IEasing
};
var motion_easing_ExpoEaseOut = function() {
};
motion_easing_ExpoEaseOut.__name__ = true;
motion_easing_ExpoEaseOut.__interfaces__ = [motion_easing_IEasing];
motion_easing_ExpoEaseOut.prototype = {
	calculate: function(k) {
		if(k == 1) return 1; else return 1 - Math.pow(2,-10 * k);
	}
	,ease: function(t,b,c,d) {
		if(t == d) return b + c; else return c * (1 - Math.pow(2,-10 * t / d)) + b;
	}
	,__class__: motion_easing_ExpoEaseOut
};
var motion_Actuate = function() { };
motion_Actuate.__name__ = true;
motion_Actuate.apply = function(target,properties,customActuator) {
	motion_Actuate.stop(target,properties);
	if(customActuator == null) customActuator = motion_Actuate.defaultActuator;
	var actuator = Type.createInstance(customActuator,[target,0,properties]);
	actuator.apply();
	return actuator;
};
motion_Actuate.getLibrary = function(target,allowCreation) {
	if(allowCreation == null) allowCreation = true;
	if(!(motion_Actuate.targetLibraries.h.__keys__[target.__id__] != null) && allowCreation) motion_Actuate.targetLibraries.set(target,[]);
	return motion_Actuate.targetLibraries.h[target.__id__];
};
motion_Actuate.isActive = function() {
	var result = false;
	var $it0 = motion_Actuate.targetLibraries.iterator();
	while( $it0.hasNext() ) {
		var library = $it0.next();
		result = true;
		break;
	}
	return result;
};
motion_Actuate.motionPath = function(target,duration,properties,overwrite) {
	if(overwrite == null) overwrite = true;
	return motion_Actuate.tween(target,duration,properties,overwrite,motion_actuators_MotionPathActuator);
};
motion_Actuate.pause = function(target) {
	if(js_Boot.__instanceof(target,motion_actuators_IGenericActuator)) {
		var actuator = target;
		actuator.pause();
	} else {
		var library = motion_Actuate.getLibrary(target,false);
		if(library != null) {
			var _g = 0;
			while(_g < library.length) {
				var actuator1 = library[_g];
				++_g;
				actuator1.pause();
			}
		}
	}
};
motion_Actuate.pauseAll = function() {
	var $it0 = motion_Actuate.targetLibraries.iterator();
	while( $it0.hasNext() ) {
		var library = $it0.next();
		var _g = 0;
		while(_g < library.length) {
			var actuator = library[_g];
			++_g;
			actuator.pause();
		}
	}
};
motion_Actuate.reset = function() {
	var $it0 = motion_Actuate.targetLibraries.iterator();
	while( $it0.hasNext() ) {
		var library = $it0.next();
		var i = library.length - 1;
		while(i >= 0) {
			library[i].stop(null,false,false);
			i--;
		}
	}
	motion_Actuate.targetLibraries = new haxe_ds_ObjectMap();
};
motion_Actuate.resume = function(target) {
	if(js_Boot.__instanceof(target,motion_actuators_IGenericActuator)) {
		var actuator = target;
		actuator.resume();
	} else {
		var library = motion_Actuate.getLibrary(target,false);
		if(library != null) {
			var _g = 0;
			while(_g < library.length) {
				var actuator1 = library[_g];
				++_g;
				actuator1.resume();
			}
		}
	}
};
motion_Actuate.resumeAll = function() {
	var $it0 = motion_Actuate.targetLibraries.iterator();
	while( $it0.hasNext() ) {
		var library = $it0.next();
		var _g = 0;
		while(_g < library.length) {
			var actuator = library[_g];
			++_g;
			actuator.resume();
		}
	}
};
motion_Actuate.stop = function(target,properties,complete,sendEvent) {
	if(sendEvent == null) sendEvent = true;
	if(complete == null) complete = false;
	if(target != null) {
		if(js_Boot.__instanceof(target,motion_actuators_IGenericActuator)) {
			var actuator = target;
			actuator.stop(null,complete,sendEvent);
		} else {
			var library = motion_Actuate.getLibrary(target,false);
			if(library != null) {
				if(typeof(properties) == "string") {
					var temp = { };
					Reflect.setField(temp,properties,null);
					properties = temp;
				} else if((properties instanceof Array) && properties.__enum__ == null) {
					var temp1 = { };
					var _g = 0;
					var _g1;
					_g1 = js_Boot.__cast(properties , Array);
					while(_g < _g1.length) {
						var property = _g1[_g];
						++_g;
						Reflect.setField(temp1,property,null);
					}
					properties = temp1;
				}
				var i = library.length - 1;
				while(i >= 0) {
					library[i].stop(properties,complete,sendEvent);
					i--;
				}
			}
		}
	}
};
motion_Actuate.timer = function(duration,customActuator) {
	return motion_Actuate.tween(new motion__$Actuate_TweenTimer(0),duration,new motion__$Actuate_TweenTimer(1),false,customActuator);
};
motion_Actuate.tween = function(target,duration,properties,overwrite,customActuator) {
	if(overwrite == null) overwrite = true;
	if(target != null) {
		if(duration > 0) {
			if(customActuator == null) customActuator = motion_Actuate.defaultActuator;
			var actuator = Type.createInstance(customActuator,[target,duration,properties]);
			var library = motion_Actuate.getLibrary(actuator.target);
			if(overwrite) {
				var i = library.length - 1;
				while(i >= 0) {
					library[i].stop(actuator.properties,false,false);
					i--;
				}
				library = motion_Actuate.getLibrary(actuator.target);
			}
			library.push(actuator);
			actuator.move();
			return actuator;
		} else return motion_Actuate.apply(target,properties,customActuator);
	}
	return null;
};
motion_Actuate.unload = function(actuator) {
	var target = actuator.target;
	if(motion_Actuate.targetLibraries.h.__keys__[target.__id__] != null) {
		HxOverrides.remove(motion_Actuate.targetLibraries.h[target.__id__],actuator);
		if(motion_Actuate.targetLibraries.h[target.__id__].length == 0) motion_Actuate.targetLibraries.remove(target);
	}
};
motion_Actuate.update = function(target,duration,start,end,overwrite) {
	if(overwrite == null) overwrite = true;
	var properties = { start : start, end : end};
	return motion_Actuate.tween(target,duration,properties,overwrite,motion_actuators_MethodActuator);
};
var motion__$Actuate_TweenTimer = function(progress) {
	this.progress = progress;
};
motion__$Actuate_TweenTimer.__name__ = true;
motion__$Actuate_TweenTimer.prototype = {
	__class__: motion__$Actuate_TweenTimer
};
var motion_MotionPath = function() {
	this._x = new motion_ComponentPath();
	this._y = new motion_ComponentPath();
	this._rotation = null;
};
motion_MotionPath.__name__ = true;
motion_MotionPath.prototype = {
	bezier: function(x,y,controlX,controlY,strength) {
		if(strength == null) strength = 1;
		this._x.addPath(new motion_BezierPath(x,controlX,strength));
		this._y.addPath(new motion_BezierPath(y,controlY,strength));
		return this;
	}
	,line: function(x,y,strength) {
		if(strength == null) strength = 1;
		this._x.addPath(new motion_LinearPath(x,strength));
		this._y.addPath(new motion_LinearPath(y,strength));
		return this;
	}
	,get_rotation: function() {
		if(this._rotation == null) this._rotation = new motion_RotationPath(this._x,this._y);
		return this._rotation;
	}
	,get_x: function() {
		return this._x;
	}
	,get_y: function() {
		return this._y;
	}
	,__class__: motion_MotionPath
	,__properties__: {get_y:"get_y",get_x:"get_x",get_rotation:"get_rotation"}
};
var motion_IComponentPath = function() { };
motion_IComponentPath.__name__ = true;
motion_IComponentPath.prototype = {
	__class__: motion_IComponentPath
	,__properties__: {get_end:"get_end"}
};
var motion_ComponentPath = function() {
	this.paths = [];
	this.start = 0;
	this.totalStrength = 0;
};
motion_ComponentPath.__name__ = true;
motion_ComponentPath.__interfaces__ = [motion_IComponentPath];
motion_ComponentPath.prototype = {
	addPath: function(path) {
		this.paths.push(path);
		this.totalStrength += path.strength;
	}
	,calculate: function(k) {
		if(this.paths.length == 1) return this.paths[0].calculate(this.start,k); else {
			var ratio = k * this.totalStrength;
			var lastEnd = this.start;
			var _g = 0;
			var _g1 = this.paths;
			while(_g < _g1.length) {
				var path = _g1[_g];
				++_g;
				if(ratio > path.strength) {
					ratio -= path.strength;
					lastEnd = path.end;
				} else return path.calculate(lastEnd,ratio / path.strength);
			}
		}
		return 0;
	}
	,get_end: function() {
		if(this.paths.length > 0) {
			var path = this.paths[this.paths.length - 1];
			return path.end;
		} else return this.start;
	}
	,__class__: motion_ComponentPath
	,__properties__: {get_end:"get_end"}
};
var motion_BezierPath = function(end,control,strength) {
	this.end = end;
	this.control = control;
	this.strength = strength;
};
motion_BezierPath.__name__ = true;
motion_BezierPath.prototype = {
	calculate: function(start,k) {
		return (1 - k) * (1 - k) * start + 2 * (1 - k) * k * this.control + k * k * this.end;
	}
	,__class__: motion_BezierPath
};
var motion_LinearPath = function(end,strength) {
	motion_BezierPath.call(this,end,0,strength);
};
motion_LinearPath.__name__ = true;
motion_LinearPath.__super__ = motion_BezierPath;
motion_LinearPath.prototype = $extend(motion_BezierPath.prototype,{
	calculate: function(start,k) {
		return start + k * (this.end - start);
	}
	,__class__: motion_LinearPath
});
var motion_RotationPath = function(x,y) {
	this.step = 0.01;
	this._x = x;
	this._y = y;
	this.offset = 0;
	this.start = this.calculate(0.0);
};
motion_RotationPath.__name__ = true;
motion_RotationPath.__interfaces__ = [motion_IComponentPath];
motion_RotationPath.prototype = {
	calculate: function(k) {
		var dX = this._x.calculate(k) - this._x.calculate(k + this.step);
		var dY = this._y.calculate(k) - this._y.calculate(k + this.step);
		var angle = Math.atan2(dY,dX) * (180 / Math.PI);
		angle = (angle + this.offset) % 360;
		return angle;
	}
	,get_end: function() {
		return this.calculate(1.0);
	}
	,__class__: motion_RotationPath
	,__properties__: {get_end:"get_end"}
};
var motion_actuators_MethodActuator = function(target,duration,properties) {
	this.currentParameters = [];
	this.tweenProperties = { };
	motion_actuators_SimpleActuator.call(this,target,duration,properties);
	if(!Object.prototype.hasOwnProperty.call(properties,"start")) this.properties.start = [];
	if(!Object.prototype.hasOwnProperty.call(properties,"end")) this.properties.end = this.properties.start;
	var _g1 = 0;
	var _g = this.properties.start.length;
	while(_g1 < _g) {
		var i = _g1++;
		this.currentParameters.push(this.properties.start[i]);
	}
};
motion_actuators_MethodActuator.__name__ = true;
motion_actuators_MethodActuator.__super__ = motion_actuators_SimpleActuator;
motion_actuators_MethodActuator.prototype = $extend(motion_actuators_SimpleActuator.prototype,{
	apply: function() {
		this.callMethod(this.target,this.properties.end);
	}
	,complete: function(sendEvent) {
		if(sendEvent == null) sendEvent = true;
		var _g1 = 0;
		var _g = this.properties.start.length;
		while(_g1 < _g) {
			var i = _g1++;
			this.currentParameters[i] = Reflect.field(this.tweenProperties,"param" + i);
		}
		this.callMethod(this.target,this.currentParameters);
		motion_actuators_SimpleActuator.prototype.complete.call(this,sendEvent);
	}
	,initialize: function() {
		var details;
		var propertyName;
		var start;
		var _g1 = 0;
		var _g = this.properties.start.length;
		while(_g1 < _g) {
			var i = _g1++;
			propertyName = "param" + i;
			start = this.properties.start[i];
			this.tweenProperties[propertyName] = start;
			if(typeof(start) == "number" || ((start | 0) === start)) {
				details = new motion_actuators_PropertyDetails(this.tweenProperties,propertyName,start,this.properties.end[i] - start);
				this.propertyDetails.push(details);
			}
		}
		this.detailsLength = this.propertyDetails.length;
		this.initialized = true;
	}
	,update: function(currentTime) {
		motion_actuators_SimpleActuator.prototype.update.call(this,currentTime);
		if(this.active && !this.paused) {
			var _g1 = 0;
			var _g = this.properties.start.length;
			while(_g1 < _g) {
				var i = _g1++;
				this.currentParameters[i] = Reflect.field(this.tweenProperties,"param" + i);
			}
			this.callMethod(this.target,this.currentParameters);
		}
	}
	,__class__: motion_actuators_MethodActuator
});
var motion_actuators_MotionPathActuator = function(target,duration,properties) {
	motion_actuators_SimpleActuator.call(this,target,duration,properties);
};
motion_actuators_MotionPathActuator.__name__ = true;
motion_actuators_MotionPathActuator.__super__ = motion_actuators_SimpleActuator;
motion_actuators_MotionPathActuator.prototype = $extend(motion_actuators_SimpleActuator.prototype,{
	apply: function() {
		var _g = 0;
		var _g1 = Reflect.fields(this.properties);
		while(_g < _g1.length) {
			var propertyName = _g1[_g];
			++_g;
			if(Object.prototype.hasOwnProperty.call(this.target,propertyName)) Reflect.setField(this.target,propertyName,(js_Boot.__cast(Reflect.field(this.properties,propertyName) , motion_IComponentPath)).get_end()); else Reflect.setProperty(this.target,propertyName,(js_Boot.__cast(Reflect.field(this.properties,propertyName) , motion_IComponentPath)).get_end());
		}
	}
	,initialize: function() {
		var details;
		var path;
		var _g = 0;
		var _g1 = Reflect.fields(this.properties);
		while(_g < _g1.length) {
			var propertyName = _g1[_g];
			++_g;
			path = js_Boot.__cast(Reflect.field(this.properties,propertyName) , motion_IComponentPath);
			if(path != null) {
				var isField = true;
				if(Object.prototype.hasOwnProperty.call(this.target,propertyName)) path.start = Reflect.field(this.target,propertyName); else {
					isField = false;
					path.start = Reflect.getProperty(this.target,propertyName);
				}
				details = new motion_actuators_PropertyPathDetails(this.target,propertyName,path,isField);
				this.propertyDetails.push(details);
			}
		}
		this.detailsLength = this.propertyDetails.length;
		this.initialized = true;
	}
	,update: function(currentTime) {
		if(!this.paused) {
			var details;
			var easing;
			var tweenPosition = (currentTime - this.timeOffset) / this.duration;
			if(tweenPosition > 1) tweenPosition = 1;
			if(!this.initialized) this.initialize();
			if(!this.special) {
				easing = this._ease.calculate(tweenPosition);
				var _g = 0;
				var _g1 = this.propertyDetails;
				while(_g < _g1.length) {
					var details1 = _g1[_g];
					++_g;
					if(details1.isField) Reflect.setField(details1.target,details1.propertyName,(js_Boot.__cast(details1 , motion_actuators_PropertyPathDetails)).path.calculate(easing)); else Reflect.setProperty(details1.target,details1.propertyName,(js_Boot.__cast(details1 , motion_actuators_PropertyPathDetails)).path.calculate(easing));
				}
			} else {
				if(!this._reverse) easing = this._ease.calculate(tweenPosition); else easing = this._ease.calculate(1 - tweenPosition);
				var endValue;
				var _g2 = 0;
				var _g11 = this.propertyDetails;
				while(_g2 < _g11.length) {
					var details2 = _g11[_g2];
					++_g2;
					if(!this._snapping) {
						if(details2.isField) Reflect.setField(details2.target,details2.propertyName,(js_Boot.__cast(details2 , motion_actuators_PropertyPathDetails)).path.calculate(easing)); else Reflect.setProperty(details2.target,details2.propertyName,(js_Boot.__cast(details2 , motion_actuators_PropertyPathDetails)).path.calculate(easing));
					} else if(details2.isField) Reflect.setField(details2.target,details2.propertyName,Math.round((js_Boot.__cast(details2 , motion_actuators_PropertyPathDetails)).path.calculate(easing))); else Reflect.setProperty(details2.target,details2.propertyName,Math.round((js_Boot.__cast(details2 , motion_actuators_PropertyPathDetails)).path.calculate(easing)));
				}
			}
			if(tweenPosition == 1) {
				if(this._repeat == 0) {
					this.active = false;
					if(this.toggleVisible && this.getField(this.target,"alpha") == 0) this.setField_motion_actuators_MotionPathActuator_T(this.target,"visible",false);
					this.complete(true);
					return;
				} else {
					if(this._onRepeat != null) this.callMethod(this._onRepeat,this._onRepeatParams);
					if(this._reflect) this._reverse = !this._reverse;
					this.startTime = currentTime;
					this.timeOffset = this.startTime + this._delay;
					if(this._repeat > 0) this._repeat--;
				}
			}
			if(this.sendChange) this.change();
		}
	}
	,__class__: motion_actuators_MotionPathActuator
});
var motion_actuators_PropertyDetails = function(target,propertyName,start,change,isField) {
	if(isField == null) isField = true;
	this.target = target;
	this.propertyName = propertyName;
	this.start = start;
	this.change = change;
	this.isField = isField;
};
motion_actuators_PropertyDetails.__name__ = true;
motion_actuators_PropertyDetails.prototype = {
	__class__: motion_actuators_PropertyDetails
};
var motion_actuators_PropertyPathDetails = function(target,propertyName,path,isField) {
	if(isField == null) isField = true;
	motion_actuators_PropertyDetails.call(this,target,propertyName,0,0,isField);
	this.path = path;
};
motion_actuators_PropertyPathDetails.__name__ = true;
motion_actuators_PropertyPathDetails.__super__ = motion_actuators_PropertyDetails;
motion_actuators_PropertyPathDetails.prototype = $extend(motion_actuators_PropertyDetails.prototype,{
	__class__: motion_actuators_PropertyPathDetails
});
var motion_easing_ExpoEaseIn = function() {
};
motion_easing_ExpoEaseIn.__name__ = true;
motion_easing_ExpoEaseIn.__interfaces__ = [motion_easing_IEasing];
motion_easing_ExpoEaseIn.prototype = {
	calculate: function(k) {
		if(k == 0) return 0; else return Math.pow(2,10 * (k - 1));
	}
	,ease: function(t,b,c,d) {
		if(t == 0) return b; else return c * Math.pow(2,10 * (t / d - 1)) + b;
	}
	,__class__: motion_easing_ExpoEaseIn
};
var motion_easing_ExpoEaseInOut = function() {
};
motion_easing_ExpoEaseInOut.__name__ = true;
motion_easing_ExpoEaseInOut.__interfaces__ = [motion_easing_IEasing];
motion_easing_ExpoEaseInOut.prototype = {
	calculate: function(k) {
		if(k == 0) return 0;
		if(k == 1) return 1;
		if((k /= 0.5) < 1.0) return 0.5 * Math.pow(2,10 * (k - 1));
		return 0.5 * (2 - Math.pow(2,-10 * --k));
	}
	,ease: function(t,b,c,d) {
		if(t == 0) return b;
		if(t == d) return b + c;
		if((t /= d / 2.0) < 1.0) return c / 2 * Math.pow(2,10 * (t - 1)) + b;
		return c / 2 * (2 - Math.pow(2,-10 * --t)) + b;
	}
	,__class__: motion_easing_ExpoEaseInOut
};
var motion_easing_Linear = function() { };
motion_easing_Linear.__name__ = true;
motion_easing_Linear.__properties__ = {get_easeNone:"get_easeNone"}
motion_easing_Linear.get_easeNone = function() {
	return new motion_easing_LinearEaseNone();
};
var motion_easing_LinearEaseNone = function() {
};
motion_easing_LinearEaseNone.__name__ = true;
motion_easing_LinearEaseNone.__interfaces__ = [motion_easing_IEasing];
motion_easing_LinearEaseNone.prototype = {
	calculate: function(k) {
		return k;
	}
	,ease: function(t,b,c,d) {
		return c * t / d + b;
	}
	,__class__: motion_easing_LinearEaseNone
};
var motion_easing_Quad = function() { };
motion_easing_Quad.__name__ = true;
motion_easing_Quad.__properties__ = {get_easeOut:"get_easeOut",get_easeInOut:"get_easeInOut",get_easeIn:"get_easeIn"}
motion_easing_Quad.get_easeIn = function() {
	return new motion_easing_QuadEaseIn();
};
motion_easing_Quad.get_easeInOut = function() {
	return new motion_easing_QuadEaseInOut();
};
motion_easing_Quad.get_easeOut = function() {
	return new motion_easing_QuadEaseOut();
};
var motion_easing_QuadEaseIn = function() {
};
motion_easing_QuadEaseIn.__name__ = true;
motion_easing_QuadEaseIn.__interfaces__ = [motion_easing_IEasing];
motion_easing_QuadEaseIn.prototype = {
	calculate: function(k) {
		return k * k;
	}
	,ease: function(t,b,c,d) {
		return c * (t /= d) * t + b;
	}
	,__class__: motion_easing_QuadEaseIn
};
var motion_easing_QuadEaseInOut = function() {
};
motion_easing_QuadEaseInOut.__name__ = true;
motion_easing_QuadEaseInOut.__interfaces__ = [motion_easing_IEasing];
motion_easing_QuadEaseInOut.prototype = {
	calculate: function(k) {
		if((k *= 2) < 1) return 0.5 * k * k;
		return -0.5 * ((k - 1) * (k - 3) - 1);
	}
	,ease: function(t,b,c,d) {
		if((t /= d / 2) < 1) return c / 2 * t * t + b;
		return -c / 2 * ((t - 1) * (t - 3) - 1) + b;
	}
	,__class__: motion_easing_QuadEaseInOut
};
var motion_easing_QuadEaseOut = function() {
};
motion_easing_QuadEaseOut.__name__ = true;
motion_easing_QuadEaseOut.__interfaces__ = [motion_easing_IEasing];
motion_easing_QuadEaseOut.prototype = {
	calculate: function(k) {
		return -k * (k - 2);
	}
	,ease: function(t,b,c,d) {
		return -c * (t /= d) * (t - 2) + b;
	}
	,__class__: motion_easing_QuadEaseOut
};
var motion_easing_Sine = function() { };
motion_easing_Sine.__name__ = true;
motion_easing_Sine.__properties__ = {get_easeOut:"get_easeOut",get_easeInOut:"get_easeInOut",get_easeIn:"get_easeIn"}
motion_easing_Sine.get_easeIn = function() {
	return new motion_easing_SineEaseIn();
};
motion_easing_Sine.get_easeInOut = function() {
	return new motion_easing_SineEaseInOut();
};
motion_easing_Sine.get_easeOut = function() {
	return new motion_easing_SineEaseOut();
};
var motion_easing_SineEaseIn = function() {
};
motion_easing_SineEaseIn.__name__ = true;
motion_easing_SineEaseIn.__interfaces__ = [motion_easing_IEasing];
motion_easing_SineEaseIn.prototype = {
	calculate: function(k) {
		return 1 - Math.cos(k * (Math.PI / 2));
	}
	,ease: function(t,b,c,d) {
		return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
	}
	,__class__: motion_easing_SineEaseIn
};
var motion_easing_SineEaseInOut = function() {
};
motion_easing_SineEaseInOut.__name__ = true;
motion_easing_SineEaseInOut.__interfaces__ = [motion_easing_IEasing];
motion_easing_SineEaseInOut.prototype = {
	calculate: function(k) {
		return -(Math.cos(Math.PI * k) - 1) / 2;
	}
	,ease: function(t,b,c,d) {
		return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
	}
	,__class__: motion_easing_SineEaseInOut
};
var motion_easing_SineEaseOut = function() {
};
motion_easing_SineEaseOut.__name__ = true;
motion_easing_SineEaseOut.__interfaces__ = [motion_easing_IEasing];
motion_easing_SineEaseOut.prototype = {
	calculate: function(k) {
		return Math.sin(k * (Math.PI / 2));
	}
	,ease: function(t,b,c,d) {
		return c * Math.sin(t / d * (Math.PI / 2)) + b;
	}
	,__class__: motion_easing_SineEaseOut
};
var msignal_Signal = function(valueClasses) {
	if(valueClasses == null) valueClasses = [];
	this.valueClasses = valueClasses;
	this.slots = msignal_SlotList.NIL;
	this.priorityBased = false;
};
msignal_Signal.__name__ = true;
msignal_Signal.prototype = {
	add: function(listener) {
		return this.registerListener(listener);
	}
	,addOnce: function(listener) {
		return this.registerListener(listener,true);
	}
	,addWithPriority: function(listener,priority) {
		if(priority == null) priority = 0;
		return this.registerListener(listener,false,priority);
	}
	,addOnceWithPriority: function(listener,priority) {
		if(priority == null) priority = 0;
		return this.registerListener(listener,true,priority);
	}
	,remove: function(listener) {
		var slot = this.slots.find(listener);
		if(slot == null) return null;
		this.slots = this.slots.filterNot(listener);
		return slot;
	}
	,removeAll: function() {
		this.slots = msignal_SlotList.NIL;
	}
	,registerListener: function(listener,once,priority) {
		if(priority == null) priority = 0;
		if(once == null) once = false;
		if(this.registrationPossible(listener,once)) {
			var newSlot = this.createSlot(listener,once,priority);
			if(!this.priorityBased && priority != 0) this.priorityBased = true;
			if(!this.priorityBased && priority == 0) this.slots = this.slots.prepend(newSlot); else this.slots = this.slots.insertWithPriority(newSlot);
			return newSlot;
		}
		return this.slots.find(listener);
	}
	,registrationPossible: function(listener,once) {
		if(!this.slots.nonEmpty) return true;
		var existingSlot = this.slots.find(listener);
		if(existingSlot == null) return true;
		if(existingSlot.once != once) throw new js__$Boot_HaxeError("You cannot addOnce() then add() the same listener without removing the relationship first.");
		return false;
	}
	,createSlot: function(listener,once,priority) {
		if(priority == null) priority = 0;
		if(once == null) once = false;
		return null;
	}
	,get_numListeners: function() {
		return this.slots.get_length();
	}
	,__class__: msignal_Signal
	,__properties__: {get_numListeners:"get_numListeners"}
};
var msignal_Signal0 = function() {
	msignal_Signal.call(this);
};
msignal_Signal0.__name__ = true;
msignal_Signal0.__super__ = msignal_Signal;
msignal_Signal0.prototype = $extend(msignal_Signal.prototype,{
	dispatch: function() {
		var slotsToProcess = this.slots;
		while(slotsToProcess.nonEmpty) {
			slotsToProcess.head.execute();
			slotsToProcess = slotsToProcess.tail;
		}
	}
	,createSlot: function(listener,once,priority) {
		if(priority == null) priority = 0;
		if(once == null) once = false;
		return new msignal_Slot0(this,listener,once,priority);
	}
	,__class__: msignal_Signal0
});
var msignal_Signal1 = function(type) {
	msignal_Signal.call(this,[type]);
};
msignal_Signal1.__name__ = true;
msignal_Signal1.__super__ = msignal_Signal;
msignal_Signal1.prototype = $extend(msignal_Signal.prototype,{
	dispatch: function(value) {
		var slotsToProcess = this.slots;
		while(slotsToProcess.nonEmpty) {
			slotsToProcess.head.execute(value);
			slotsToProcess = slotsToProcess.tail;
		}
	}
	,createSlot: function(listener,once,priority) {
		if(priority == null) priority = 0;
		if(once == null) once = false;
		return new msignal_Slot1(this,listener,once,priority);
	}
	,__class__: msignal_Signal1
});
var msignal_Signal2 = function(type1,type2) {
	msignal_Signal.call(this,[type1,type2]);
};
msignal_Signal2.__name__ = true;
msignal_Signal2.__super__ = msignal_Signal;
msignal_Signal2.prototype = $extend(msignal_Signal.prototype,{
	dispatch: function(value1,value2) {
		var slotsToProcess = this.slots;
		while(slotsToProcess.nonEmpty) {
			slotsToProcess.head.execute(value1,value2);
			slotsToProcess = slotsToProcess.tail;
		}
	}
	,createSlot: function(listener,once,priority) {
		if(priority == null) priority = 0;
		if(once == null) once = false;
		return new msignal_Slot2(this,listener,once,priority);
	}
	,__class__: msignal_Signal2
});
var msignal_Slot = function(signal,listener,once,priority) {
	if(priority == null) priority = 0;
	if(once == null) once = false;
	this.signal = signal;
	this.set_listener(listener);
	this.once = once;
	this.priority = priority;
	this.enabled = true;
};
msignal_Slot.__name__ = true;
msignal_Slot.prototype = {
	remove: function() {
		this.signal.remove(this.listener);
	}
	,set_listener: function(value) {
		if(value == null) throw new js__$Boot_HaxeError("listener cannot be null");
		return this.listener = value;
	}
	,__class__: msignal_Slot
	,__properties__: {set_listener:"set_listener"}
};
var msignal_Slot0 = function(signal,listener,once,priority) {
	if(priority == null) priority = 0;
	if(once == null) once = false;
	msignal_Slot.call(this,signal,listener,once,priority);
};
msignal_Slot0.__name__ = true;
msignal_Slot0.__super__ = msignal_Slot;
msignal_Slot0.prototype = $extend(msignal_Slot.prototype,{
	execute: function() {
		if(!this.enabled) return;
		if(this.once) this.remove();
		this.listener();
	}
	,__class__: msignal_Slot0
});
var msignal_Slot1 = function(signal,listener,once,priority) {
	if(priority == null) priority = 0;
	if(once == null) once = false;
	msignal_Slot.call(this,signal,listener,once,priority);
};
msignal_Slot1.__name__ = true;
msignal_Slot1.__super__ = msignal_Slot;
msignal_Slot1.prototype = $extend(msignal_Slot.prototype,{
	execute: function(value1) {
		if(!this.enabled) return;
		if(this.once) this.remove();
		if(this.param != null) value1 = this.param;
		this.listener(value1);
	}
	,__class__: msignal_Slot1
});
var msignal_Slot2 = function(signal,listener,once,priority) {
	if(priority == null) priority = 0;
	if(once == null) once = false;
	msignal_Slot.call(this,signal,listener,once,priority);
};
msignal_Slot2.__name__ = true;
msignal_Slot2.__super__ = msignal_Slot;
msignal_Slot2.prototype = $extend(msignal_Slot.prototype,{
	execute: function(value1,value2) {
		if(!this.enabled) return;
		if(this.once) this.remove();
		if(this.param1 != null) value1 = this.param1;
		if(this.param2 != null) value2 = this.param2;
		this.listener(value1,value2);
	}
	,__class__: msignal_Slot2
});
var msignal_SlotList = function(head,tail) {
	this.nonEmpty = false;
	if(head == null && tail == null) {
		if(msignal_SlotList.NIL != null) throw new js__$Boot_HaxeError("Parameters head and tail are null. Use the NIL element instead.");
		this.nonEmpty = false;
	} else if(head == null) throw new js__$Boot_HaxeError("Parameter head cannot be null."); else {
		this.head = head;
		if(tail == null) this.tail = msignal_SlotList.NIL; else this.tail = tail;
		this.nonEmpty = true;
	}
};
msignal_SlotList.__name__ = true;
msignal_SlotList.prototype = {
	get_length: function() {
		if(!this.nonEmpty) return 0;
		if(this.tail == msignal_SlotList.NIL) return 1;
		var result = 0;
		var p = this;
		while(p.nonEmpty) {
			++result;
			p = p.tail;
		}
		return result;
	}
	,prepend: function(slot) {
		return new msignal_SlotList(slot,this);
	}
	,append: function(slot) {
		if(slot == null) return this;
		if(!this.nonEmpty) return new msignal_SlotList(slot);
		if(this.tail == msignal_SlotList.NIL) return new msignal_SlotList(slot).prepend(this.head);
		var wholeClone = new msignal_SlotList(this.head);
		var subClone = wholeClone;
		var current = this.tail;
		while(current.nonEmpty) {
			subClone = subClone.tail = new msignal_SlotList(current.head);
			current = current.tail;
		}
		subClone.tail = new msignal_SlotList(slot);
		return wholeClone;
	}
	,insertWithPriority: function(slot) {
		if(!this.nonEmpty) return new msignal_SlotList(slot);
		var priority = slot.priority;
		if(priority >= this.head.priority) return this.prepend(slot);
		var wholeClone = new msignal_SlotList(this.head);
		var subClone = wholeClone;
		var current = this.tail;
		while(current.nonEmpty) {
			if(priority > current.head.priority) {
				subClone.tail = current.prepend(slot);
				return wholeClone;
			}
			subClone = subClone.tail = new msignal_SlotList(current.head);
			current = current.tail;
		}
		subClone.tail = new msignal_SlotList(slot);
		return wholeClone;
	}
	,filterNot: function(listener) {
		if(!this.nonEmpty || listener == null) return this;
		if(Reflect.compareMethods(this.head.listener,listener)) return this.tail;
		var wholeClone = new msignal_SlotList(this.head);
		var subClone = wholeClone;
		var current = this.tail;
		while(current.nonEmpty) {
			if(Reflect.compareMethods(current.head.listener,listener)) {
				subClone.tail = current.tail;
				return wholeClone;
			}
			subClone = subClone.tail = new msignal_SlotList(current.head);
			current = current.tail;
		}
		return this;
	}
	,contains: function(listener) {
		if(!this.nonEmpty) return false;
		var p = this;
		while(p.nonEmpty) {
			if(Reflect.compareMethods(p.head.listener,listener)) return true;
			p = p.tail;
		}
		return false;
	}
	,find: function(listener) {
		if(!this.nonEmpty) return null;
		var p = this;
		while(p.nonEmpty) {
			if(Reflect.compareMethods(p.head.listener,listener)) return p.head;
			p = p.tail;
		}
		return null;
	}
	,__class__: msignal_SlotList
	,__properties__: {get_length:"get_length"}
};
var shaders_SkyShader = function() { };
shaders_SkyShader.__name__ = true;
var shaders_SkyEffectController = function() {
	this.mieKCoefficient = new THREE.Vector3();
	this.primaries = new THREE.Vector3();
	this.cameraPos = new THREE.Vector3();
	this.sunPosition = new THREE.Vector3();
	this.sunPosition.set(0,-700000,0);
	this.cameraPos.set(100000.0,-40000.0,0.0);
	this.turbidity = 2.0;
	this.rayleigh = 1.0;
	this.mieCoefficient = 0.005;
	this.mieDirectionalG = 0.8;
	this.luminance = 1.0;
	this.inclination = 0.49;
	this.azimuth = 0.25;
	this.refractiveIndex = 1.0003;
	this.numMolecules = 2.542e25;
	this.depolarizationFactor = 0.035;
	this.primaries.set(6.8e-7,5.5e-7,4.5e-7);
	this.mieKCoefficient.set(0.686,0.678,0.666);
	this.mieV = 4.0;
	this.rayleighZenithLength = 8.4e3;
	this.mieZenithLength = 1.25e3;
	this.sunIntensityFactor = 1000.0;
	this.sunIntensityFalloffSteepness = 1.5;
	this.sunAngularDiameterDegrees = 0.0093333;
	this.updateUniforms();
};
shaders_SkyEffectController.__name__ = true;
shaders_SkyEffectController.prototype = {
	setInitialValues: function() {
		this.sunPosition.set(0,-700000,0);
		this.cameraPos.set(100000.0,-40000.0,0.0);
		this.turbidity = 2.0;
		this.rayleigh = 1.0;
		this.mieCoefficient = 0.005;
		this.mieDirectionalG = 0.8;
		this.luminance = 1.0;
		this.inclination = 0.49;
		this.azimuth = 0.25;
		this.refractiveIndex = 1.0003;
		this.numMolecules = 2.542e25;
		this.depolarizationFactor = 0.035;
		this.primaries.set(6.8e-7,5.5e-7,4.5e-7);
		this.mieKCoefficient.set(0.686,0.678,0.666);
		this.mieV = 4.0;
		this.rayleighZenithLength = 8.4e3;
		this.mieZenithLength = 1.25e3;
		this.sunIntensityFactor = 1000.0;
		this.sunIntensityFalloffSteepness = 1.5;
		this.sunAngularDiameterDegrees = 0.0093333;
	}
	,updateUniforms: function() {
		shaders_SkyShader.uniforms.cameraPos.value = this.cameraPos;
		shaders_SkyShader.uniforms.turbidity.value = this.turbidity;
		shaders_SkyShader.uniforms.rayleigh.value = this.rayleigh;
		shaders_SkyShader.uniforms.mieCoefficient.value = this.mieCoefficient;
		shaders_SkyShader.uniforms.mieDirectionalG.value = this.mieDirectionalG;
		shaders_SkyShader.uniforms.luminance.value = this.luminance;
		var theta = Math.PI * (this.inclination - 0.5);
		var phi = 2 * Math.PI * (this.azimuth - 0.5);
		var distance = 400000;
		this.sunPosition.x = distance * Math.cos(phi);
		this.sunPosition.y = distance * Math.sin(phi) * Math.sin(theta);
		this.sunPosition.z = distance * Math.sin(phi) * Math.cos(theta);
		shaders_SkyShader.uniforms.sunPosition.value.copy(this.sunPosition);
		shaders_SkyShader.uniforms.refractiveIndex.value = this.refractiveIndex;
		shaders_SkyShader.uniforms.numMolecules.value = this.numMolecules;
		shaders_SkyShader.uniforms.depolarizationFactor.value = this.depolarizationFactor;
		shaders_SkyShader.uniforms.rayleighZenithLength.value = this.rayleighZenithLength;
		shaders_SkyShader.uniforms.primaries.value.copy(this.primaries);
		shaders_SkyShader.uniforms.mieKCoefficient.value.copy(this.mieKCoefficient);
		shaders_SkyShader.uniforms.mieV.value = this.mieV;
		shaders_SkyShader.uniforms.mieZenithLength.value = this.mieZenithLength;
		shaders_SkyShader.uniforms.sunIntensityFactor.value = this.sunIntensityFactor;
		shaders_SkyShader.uniforms.sunIntensityFalloffSteepness.value = this.sunIntensityFalloffSteepness;
		shaders_SkyShader.uniforms.sunAngularDiameterDegrees.value = this.sunAngularDiameterDegrees;
		console.log(this.primaries);
	}
	,addGUIItem: function(c,gui) {
		var controller = c;
		var updateValues = function(t) {
			controller.updateUniforms();
		};
		gui.add(controller,"turbidity").step(0.025).listen().onChange(updateValues);
		gui.add(controller,"rayleigh").step(0.005).listen().onChange(updateValues);
		gui.add(controller,"mieCoefficient").step(0.000025).listen().onChange(updateValues);
		gui.add(controller,"mieDirectionalG").step(0.001).listen().onChange(updateValues);
		gui.add(controller,"luminance").step(0.0005).listen().onChange(updateValues);
		gui.add(controller,"inclination").step(0.0001).listen().onChange(updateValues);
		gui.add(controller,"azimuth").step(0.0001).listen().onChange(updateValues);
		gui.add(controller,"refractiveIndex").step(0.000001).listen().onChange(updateValues);
		gui.add(controller,"numMolecules",2.542e10,2.542e26,1e10).listen().onChange(updateValues);
		gui.add(controller,"depolarizationFactor").step(0.001).listen().onChange(updateValues);
		gui.add(controller,"rayleighZenithLength").step(15.0).listen().onChange(updateValues);
		gui.add(controller,"mieV").step(0.001).listen().onChange(updateValues);
		gui.add(controller,"mieZenithLength").step(100.0).listen().onChange(updateValues);
		gui.add(controller,"sunIntensityFactor").step(1.0).listen().onChange(updateValues);
		gui.add(controller,"sunIntensityFalloffSteepness").step(0.01).listen().onChange(updateValues);
		gui.add(controller,"sunAngularDiameterDegrees").step(0.00001).listen().onChange(updateValues);
		var primariesFolder = gui.addFolder("primaries");
		primariesFolder.add(controller.primaries,"x",5e-12,9e-7,5e-13).listen().onChange(updateValues);
		primariesFolder.add(controller.primaries,"y",5e-12,9e-7,5e-13).listen().onChange(updateValues);
		primariesFolder.add(controller.primaries,"z",5e-12,9e-7,5e-13).listen().onChange(updateValues);
		var mieFolder = gui.addFolder("mieCoefficient");
		mieFolder.add(controller.mieKCoefficient,"x").step(0.001).listen().onChange(updateValues);
		mieFolder.add(controller.mieKCoefficient,"y").step(0.001).listen().onChange(updateValues);
		mieFolder.add(controller.mieKCoefficient,"z").step(0.001).listen().onChange(updateValues);
		var camFolder = gui.addFolder("cameraPos");
		camFolder.add(controller.cameraPos,"x").step(250).listen().onChange(updateValues);
		camFolder.add(controller.cameraPos,"y").step(250).listen().onChange(updateValues);
		camFolder.add(controller.cameraPos,"z").step(250).listen().onChange(updateValues);
	}
	,__class__: shaders_SkyEffectController
};
var util_FileReader = function() { };
util_FileReader.__name__ = true;
var $_, $fid = 0;
function $bind(o,m) { if( m == null ) return null; if( m.__id__ == null ) m.__id__ = $fid++; var f; if( o.hx__closures__ == null ) o.hx__closures__ = {}; else f = o.hx__closures__[m.__id__]; if( f == null ) { f = function(){ return f.method.apply(f.scope, arguments); }; f.scope = o; f.method = m; o.hx__closures__[m.__id__] = f; } return f; }
if(Array.prototype.indexOf) HxOverrides.indexOf = function(a,o,i) {
	return Array.prototype.indexOf.call(a,o,i);
};
String.prototype.__class__ = String;
String.__name__ = true;
Array.__name__ = true;
Date.prototype.__class__ = Date;
Date.__name__ = ["Date"];
var Int = { __name__ : ["Int"]};
var Dynamic = { __name__ : ["Dynamic"]};
var Float = Number;
Float.__name__ = ["Float"];
var Bool = Boolean;
Bool.__ename__ = ["Bool"];
var Class = { __name__ : ["Class"]};
var Enum = { };
/**
 * @author mrdoob / http://mrdoob.com/
 */

var Stats = function () {

	var startTime = Date.now(), prevTime = startTime;
	var ms = 0, msMin = Infinity, msMax = 0;
	var fps = 0, fpsMin = Infinity, fpsMax = 0;
	var frames = 0, mode = 0;

	var container = document.createElement( 'div' );
	container.id = 'stats';
	container.addEventListener( 'mousedown', function ( event ) { event.preventDefault(); setMode( ++ mode % 2 ) }, false );
	container.style.cssText = 'width:80px;opacity:0.9;cursor:pointer';

	var fpsDiv = document.createElement( 'div' );
	fpsDiv.id = 'fps';
	fpsDiv.style.cssText = 'padding:0 0 3px 3px;text-align:left;background-color:#002';
	container.appendChild( fpsDiv );

	var fpsText = document.createElement( 'div' );
	fpsText.id = 'fpsText';
	fpsText.style.cssText = 'color:#0ff;font-family:Helvetica,Arial,sans-serif;font-size:9px;font-weight:bold;line-height:15px';
	fpsText.innerHTML = 'FPS';
	fpsDiv.appendChild( fpsText );

	var fpsGraph = document.createElement( 'div' );
	fpsGraph.id = 'fpsGraph';
	fpsGraph.style.cssText = 'position:relative;width:74px;height:30px;background-color:#0ff';
	fpsDiv.appendChild( fpsGraph );

	while ( fpsGraph.children.length < 74 ) {

		var bar = document.createElement( 'span' );
		bar.style.cssText = 'width:1px;height:30px;float:left;background-color:#113';
		fpsGraph.appendChild( bar );

	}

	var msDiv = document.createElement( 'div' );
	msDiv.id = 'ms';
	msDiv.style.cssText = 'padding:0 0 3px 3px;text-align:left;background-color:#020;display:none';
	container.appendChild( msDiv );

	var msText = document.createElement( 'div' );
	msText.id = 'msText';
	msText.style.cssText = 'color:#0f0;font-family:Helvetica,Arial,sans-serif;font-size:9px;font-weight:bold;line-height:15px';
	msText.innerHTML = 'MS';
	msDiv.appendChild( msText );

	var msGraph = document.createElement( 'div' );
	msGraph.id = 'msGraph';
	msGraph.style.cssText = 'position:relative;width:74px;height:30px;background-color:#0f0';
	msDiv.appendChild( msGraph );

	while ( msGraph.children.length < 74 ) {

		var bar = document.createElement( 'span' );
		bar.style.cssText = 'width:1px;height:30px;float:left;background-color:#131';
		msGraph.appendChild( bar );

	}

	var setMode = function ( value ) {

		mode = value;

		switch ( mode ) {

			case 0:
				fpsDiv.style.display = 'block';
				msDiv.style.display = 'none';
				break;
			case 1:
				fpsDiv.style.display = 'none';
				msDiv.style.display = 'block';
				break;
		}

	}

	var updateGraph = function ( dom, value ) {

		var child = dom.appendChild( dom.firstChild );
		child.style.height = value + 'px';

	}

	return {

		REVISION: 11,

		domElement: container,

		setMode: setMode,

		begin: function () {

			startTime = Date.now();

		},

		end: function () {

			var time = Date.now();

			ms = time - startTime;
			msMin = Math.min( msMin, ms );
			msMax = Math.max( msMax, ms );

			msText.textContent = ms + ' MS (' + msMin + '-' + msMax + ')';
			updateGraph( msGraph, Math.min( 30, 30 - ( ms / 200 ) * 30 ) );

			frames ++;

			if ( time > prevTime + 1000 ) {

				fps = Math.round( ( frames * 1000 ) / ( time - prevTime ) );
				fpsMin = Math.min( fpsMin, fps );
				fpsMax = Math.max( fpsMax, fps );

				fpsText.textContent = fps + ' FPS (' + fpsMin + '-' + fpsMax + ')';
				updateGraph( fpsGraph, Math.min( 30, 30 - ( fps / 100 ) * 30 ) );

				prevTime = time;
				frames = 0;

			}

			return time;

		},

		update: function () {

			startTime = this.end();

		}

	}

};
;
msignal_SlotList.NIL = new msignal_SlotList(null,null);
Main.DEGREES_TO_RAD = 0.01745329;
Main.GAME_VIEWPORT_WIDTH = 800;
Main.GAME_VIEWPORT_HEIGHT = 500;
Main.REPO_URL = "https://github.com/Tw1ddle/Ludum-Dare-33";
Main.TWITTER_URL = "https://twitter.com/Sam_Twidale";
Main.LUDUM_DARE_URL = "http://ludumdare.com/";
Main.WEBSITE_URL = "http://samcodes.co.uk/";
haxe_ds_ObjectMap.count = 0;
js_Boot.__toStr = {}.toString;
ludum_Player.vocabulary = ["twinkle","glow","sparkle","glimmer","gleam","glint","blaze","flicker","glitter","shimmer","glare","shine"];
ludum_screens_ScreenFour.godTalk = [{ text : "So you came back...", color : "#FFBF00"},{ text : "I thought we had been through this before...", color : "#2ECCFA"},{ text : "You cannot have your followers back...", color : "#CEF6F5"},{ text : "You LESSER Gods conspire to stop ME?", color : "#990000"},{ text : "Where are they? You stole them didn't you!", color : "#990000"},{ text : "Do you remember nothing?", color : "#FFBF00"},{ text : "You undid yourself when you charred your lands in a rage!", color : "#FFBF00"},{ text : "Even now the proof of your crimes lies in your wake. Fool.", color : "#FFBF00"},{ text : "You have but a single follower left!", color : "#CEF6F5"},{ text : "Let us put an end to this farce?", color : "#FFBF00"},{ text : "Yes!", color : "#2ECCFA"},{ text : "Indeed! Time is up.", color : "#CEF6F5"},{ text : "It is decided. Come back when you have atoned for your crimes...!", color : "#FFBF00"},{ text : "Now begone!", color : "#FFBF00"}];
motion_actuators_SimpleActuator.actuators = [];
motion_actuators_SimpleActuator.actuatorsLength = 0;
motion_actuators_SimpleActuator.addedEvent = false;
motion_Actuate.defaultActuator = motion_actuators_SimpleActuator;
motion_Actuate.defaultEase = motion_easing_Expo.get_easeOut();
motion_Actuate.targetLibraries = new haxe_ds_ObjectMap();
shaders_SkyShader.uniforms = { luminance : { type : "f", value : 1.0}, turbidity : { type : "f", value : 1.0}, rayleigh : { type : "f", value : 1.0}, mieCoefficient : { type : "f", value : 1.0}, mieDirectionalG : { type : "f", value : 1.0}, sunPosition : { type : "v3", value : new THREE.Vector3()}, cameraPos : { type : "v3", value : new THREE.Vector3()}, refractiveIndex : { type : "f", value : 1.0}, numMolecules : { type : "f", value : 1.0}, depolarizationFactor : { type : "f", value : 1.0}, primaries : { type : "v3", value : new THREE.Vector3()}, mieKCoefficient : { type : "v3", value : new THREE.Vector3()}, mieV : { type : "f", value : 1.0}, rayleighZenithLength : { type : "f", value : 1.0}, mieZenithLength : { type : "f", value : 1.0}, sunIntensityFactor : { type : "f", value : 1.0}, sunIntensityFalloffSteepness : { type : "f", value : 1.0}, sunAngularDiameterDegrees : { type : "f", value : 1.0}};
shaders_SkyShader.vertexShader = "varying vec3 vWorldPosition;\r\n\r\nvoid main()\r\n{\r\n\tvec4 worldPosition = modelMatrix * vec4(position, 1.0);\r\n\tvWorldPosition = worldPosition.xyz;\r\n\tgl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);\r\n}";
shaders_SkyShader.fragmentShader = "varying vec3 vWorldPosition;\r\n\r\nuniform vec3 sunPosition;\r\nuniform float luminance;\r\nuniform float turbidity;\r\nuniform float rayleigh;\r\nuniform float mieCoefficient;\r\nuniform float mieDirectionalG;\r\nuniform vec3 cameraPos;\r\nuniform float refractiveIndex;\r\nuniform float numMolecules;\r\nuniform float depolarizationFactor;\r\nuniform vec3 primaries;\r\nuniform vec3 mieKCoefficient;\r\nuniform float mieV;\r\nuniform float rayleighZenithLength;\r\nuniform float mieZenithLength;\r\nuniform float sunIntensityFactor;\r\nuniform float sunIntensityFalloffSteepness;\r\nuniform float sunAngularDiameterDegrees;\r\n\r\nconst float pi = 3.141592653589793238462643383279502884197169;\r\nconst vec3 up = vec3(0.0, 1.0, 0.0);\r\n\r\nvec3 totalRayleigh(vec3 lambda)\r\n{\r\n\treturn (8.0 * pow(pi, 3.0) * pow(pow(refractiveIndex, 2.0) - 1.0, 2.0) * (6.0 + 3.0 * depolarizationFactor)) / (3.0 * numMolecules * pow(lambda, vec3(4.0)) * (6.0 - 7.0 * depolarizationFactor));\r\n}\r\n\r\nvec3 totalMie(vec3 lambda, vec3 K, float T)\r\n{\r\n\tfloat c = 0.2 * T * 10e-18;\r\n\treturn 0.434 * c * pi * pow((2.0 * pi) / lambda, vec3(mieV - 2.0)) * K;\r\n}\r\n\r\nfloat rayleighPhase(float cosTheta)\r\n{\r\n\treturn (3.0 / (16.0 * pi)) * (1.0 + pow(cosTheta, 2.0));\r\n}\r\n\r\nfloat henyeyGreensteinPhase(float cosTheta, float g)\r\n{\r\n\treturn (1.0 / (4.0 * pi)) * ((1.0 - pow(g, 2.0)) / pow(1.0 - 2.0 * g * cosTheta + pow(g, 2.0), 1.5));\r\n}\r\n\r\nfloat sunIntensity(float zenithAngleCos)\r\n{\r\n\tfloat cutoffAngle = pi / 1.95; // Earth shadow hack\r\n\treturn sunIntensityFactor * max(0.0, 1.0 - exp(-((cutoffAngle - acos(zenithAngleCos)) / sunIntensityFalloffSteepness)));\r\n}\r\n\r\n// Whitescale tonemapping calculation, see http://filmicgames.com/archives/75\r\n// Also see http://blenderartists.org/forum/showthread.php?321110-Shaders-and-Skybox-madness\r\nconst float A = 0.15; // Shoulder strength\r\nconst float B = 0.50; // Linear strength\r\nconst float C = 0.10; // Linear angle\r\nconst float D = 0.20; // Toe strength\r\nconst float E = 0.02; // Toe numerator\r\nconst float F = 0.30; // Toe denominator\r\nvec3 Uncharted2Tonemap(vec3 W)\r\n{\r\n\treturn ((W * (A * W + C * B) + D * E) / (W * (A * W + B) + D * F)) - E / F;\r\n}\r\n\r\nvoid main() \r\n{\t\t\r\n\t// Rayleigh coefficients\r\n\tfloat sunfade = 1.0 - clamp(1.0 - exp((sunPosition.y / 450000.0)), 0.0, 1.0);\r\n\tfloat rayleighCoefficient = rayleigh - (1.0 * (1.0 - sunfade));\r\n\t\r\n\t// Mie coefficients\r\n\tvec3 betaM = totalMie(primaries, mieKCoefficient, turbidity) * mieCoefficient;\r\n\tvec3 betaR = totalRayleigh(primaries) * rayleighCoefficient;\r\n\t\r\n\t// Optical length, cutoff angle at 90 to avoid singularity\r\n\tfloat zenithAngle = acos(max(0.0, dot(up, normalize(vWorldPosition - cameraPos))));\r\n\tfloat denom = cos(zenithAngle) + 0.15 * pow(93.885 - ((zenithAngle * 180.0) / pi), -1.253);\r\n\tfloat sR = rayleighZenithLength / denom;\r\n\tfloat sM = mieZenithLength / denom;\r\n\r\n\t// Combined extinction factor\r\n\tvec3 Fex = exp(-(betaR * sR + betaM * sM));\r\n\t\r\n\t// In-scattering\r\n\tvec3 sunDirection = normalize(sunPosition);\r\n\tfloat cosTheta = dot(normalize(vWorldPosition - cameraPos), sunDirection);\r\n\tvec3 betaRTheta = betaR * rayleighPhase(cosTheta * 0.5 + 0.5);\r\n\tvec3 betaMTheta = betaM * henyeyGreensteinPhase(cosTheta, mieDirectionalG);\r\n\tfloat sunE = sunIntensity(dot(sunDirection, up));\r\n\tvec3 Lin = pow(sunE * ((betaRTheta + betaMTheta) / (betaR + betaM)) * (1.0 - Fex), vec3(1.5));\r\n\tLin *= mix(vec3(1.0), pow(sunE * ((betaRTheta + betaMTheta) / (betaR + betaM)) * Fex, vec3(0.5)), clamp(pow(1.0 - dot(up, sunDirection), 5.0), 0.0, 1.0));\r\n\t\r\n\t// Composition + solar disc\r\n\tfloat sunAngularDiameterCos = cos(sunAngularDiameterDegrees);\r\n\tfloat sundisk = smoothstep(sunAngularDiameterCos, sunAngularDiameterCos + 0.00002, cosTheta);\r\n\tvec3 L0 = vec3(0.1) * Fex;\r\n\tL0 += sunE * 19000.0 * Fex * sundisk;\r\n\tvec3 texColor = Lin + L0;\r\n\ttexColor *= 0.04;\r\n\ttexColor += vec3(0.0, 0.001, 0.0025) * 0.3;\r\n\t\r\n\t// Tonemapping\r\n\tfloat weighting = 1000.0;\r\n\tvec3 whiteScale = 1.0 / Uncharted2Tonemap(vec3(weighting)); \r\n\tvec3 curr = Uncharted2Tonemap((log2(2.0 / pow(luminance, 4.0))) * texColor);\r\n\tvec3 color = curr * whiteScale;\r\n\t\r\n\tvec3 retColor = pow(color, vec3(1.0 / (1.2 + (1.2 * sunfade))));\r\n\tgl_FragColor.xyz = retColor;\r\n\tgl_FragColor.w = 1.0;\r\n}";
Main.main();
})(typeof console != "undefined" ? console : {log:function(){}});

//# sourceMappingURL=game.js.map